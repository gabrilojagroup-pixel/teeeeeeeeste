import { type NextRequest, NextResponse } from "next/server"
import { poseidonAPI } from "@/lib/poseidon-api"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { amount, userEmail, userName, userDocument, userPhone } = body

    if (!amount || !userEmail || !userName || !userDocument || !userPhone) {
      return NextResponse.json(
        {
          success: false,
          error: "Todos os campos são obrigatórios: nome, CPF, telefone e valor",
        },
        { status: 400 },
      )
    }

    const identifier = `DEP-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

    const host = request.headers.get("host")
    const protocol = request.headers.get("x-forwarded-proto") || "https"
    const callbackUrl = host ? `${protocol}://${host}/api/webhooks/pix` : undefined

    console.log("[v0] Creating PIX payment with:", { identifier, amount, userName, callbackUrl })

    const response = await poseidonAPI.createPixPayment({
      identifier,
      amount,
      client: {
        name: userName,
        email: userEmail,
        phone: userPhone,
        document: userDocument,
      },
      ...(callbackUrl && { callbackUrl }),
    })

    console.log("[v0] PIX payment created successfully:", response)

    return NextResponse.json({
      success: true,
      data: response,
      identifier,
    })
  } catch (error: any) {
    console.error("[v0] Error creating PIX payment:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Erro ao criar pagamento PIX",
      },
      { status: 400 },
    )
  }
}
