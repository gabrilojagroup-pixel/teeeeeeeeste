import { type NextRequest, NextResponse } from "next/server"
import { poseidonAPI } from "@/lib/poseidon-api"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { amount, pixKey, pixKeyType, receiverName, receiverDocument, userId } = body

    let clientIp =
      request.headers.get("x-forwarded-for")?.split(",")[0] || request.headers.get("x-real-ip") || "127.0.0.1"

    // API rejects local IPs, use placeholder public IP for development
    if (
      clientIp === "127.0.0.1" ||
      clientIp === "::1" ||
      clientIp.startsWith("192.168.") ||
      clientIp.startsWith("10.")
    ) {
      clientIp = "8.8.8.8" // Use valid public IP for development
    }

    const identifier = `WTD-${userId}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

    const response = await poseidonAPI.createWithdrawal({
      identifier,
      amount,
      pixKey,
      pixKeyType,
      receiverName,
      receiverDocument,
      clientIp,
    })

    return NextResponse.json({
      success: true,
      data: response,
      identifier,
    })
  } catch (error: any) {
    console.error("[v0] Error creating withdrawal:", error)
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Erro ao criar saque",
      },
      { status: 400 },
    )
  }
}
