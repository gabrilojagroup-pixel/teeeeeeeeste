import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    console.log("[v0] PIX Webhook received:", JSON.stringify(body, null, 2))

    const { id, clientIdentifier, status, amount, paymentMethod } = body

    if (status === "COMPLETED" && clientIdentifier) {
      console.log(`[v0] Payment completed: ${id} - Amount: ${amount} - Identifier: ${clientIdentifier}`)

      // This will be picked up by the frontend to update the user's balance
      if (typeof window !== "undefined") {
        const pendingDeposits = JSON.parse(localStorage.getItem("pendingDeposits") || "[]")
        const updatedDeposits = pendingDeposits.map((deposit: any) => {
          if (deposit.identifier === clientIdentifier) {
            return { ...deposit, status: "COMPLETED", completedAt: new Date().toISOString() }
          }
          return deposit
        })
        localStorage.setItem("pendingDeposits", JSON.stringify(updatedDeposits))
      }
    }

    // Return success so PoseidonPay knows we received the webhook
    return NextResponse.json({ received: true, status: "processed" })
  } catch (error: any) {
    console.error("[v0] Webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}
