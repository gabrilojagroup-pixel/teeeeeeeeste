"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import {
  UserIcon,
  EnvelopeIcon,
  LockClosedIcon,
  PhoneIcon,
  EyeIcon,
  EyeSlashIcon,
  CheckCircleIcon,
  SparklesIcon,
} from "@heroicons/react/24/solid"
import Link from "next/link"

export default function RegisterForm() {
  const searchParams = useSearchParams()
  const [sponsorCode, setSponsorCode] = useState("")
  const [nome, setNome] = useState("")
  const [email, setEmail] = useState("")
  const [telefone, setTelefone] = useState("")
  const [senha, setSenha] = useState("")
  const [confirmarSenha, setConfirmarSenha] = useState("")
  const [mostrarSenha, setMostrarSenha] = useState(false)
  const [mostrarConfirmar, setMostrarConfirmar] = useState(false)
  const [erro, setErro] = useState("")
  const [sucesso, setSucesso] = useState(false)
  const [usersCount, setUsersCount] = useState(15847)

  useEffect(() => {
    const ref = searchParams.get("ref")
    if (ref) {
      setSponsorCode(ref)
    }

    const interval = setInterval(() => {
      setUsersCount((prev) => prev + Math.floor(Math.random() * 3))
    }, 8000)
    return () => clearInterval(interval)
  }, [searchParams])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setErro("")

    if (!nome || !email || !telefone || !senha || !confirmarSenha) {
      setErro("Preencha todos os campos")
      return
    }

    if (senha !== confirmarSenha) {
      setErro("As senhas não coincidem")
      return
    }

    if (senha.length < 6) {
      setErro("A senha deve ter no mínimo 6 caracteres")
      return
    }

    const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]")

    if (usuarios.some((u: any) => u.email === email)) {
      setErro("Este e-mail já está cadastrado")
      return
    }

    let validSponsor = ""
    if (sponsorCode) {
      const sponsorUser = usuarios.find((u: any) => u.referralCode === sponsorCode)
      if (sponsorUser) {
        validSponsor = sponsorCode
      } else {
        setErro("Código de indicação inválido")
        return
      }
    }

    const generateReferralCode = (): string => {
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
      let code = "FUT"
      for (let i = 0; i < 6; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length))
      }
      // Check if code already exists
      if (usuarios.some((u: any) => u.referralCode === code)) {
        return generateReferralCode()
      }
      return code
    }

    const novoUsuario = {
      id: Date.now(),
      nome,
      email,
      telefone,
      senha,
      sponsor: validSponsor,
      referralCode: generateReferralCode(),
      saldo: 0,
      rendimento: 0,
      bonusRef: 0,
      indicados: 0,
      nivel: 1,
      dataCriacao: new Date().toISOString(),
    }

    usuarios.push(novoUsuario)
    localStorage.setItem("usuarios", JSON.stringify(usuarios))
    localStorage.setItem("usuarioLogado", JSON.stringify(novoUsuario))

    setSucesso(true)
    setTimeout(() => {
      window.location.href = "/dashboard"
    }, 2000)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 dark:from-slate-950 dark:via-indigo-950 dark:to-purple-950 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-8 items-center">
        {/* Lado Esquerdo - Hero */}
        <div className="hidden lg:block space-y-8">
          <div className="flex items-center gap-3 mb-8">
            <div className="h-14 w-14 grid place-items-center rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-2xl shadow-indigo-500/50">
              <SparklesIcon className="h-8 w-8 text-white" />
            </div>
            <span className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              InvestFutura
            </span>
          </div>

          <div className="space-y-6">
            <h1 className="text-5xl font-bold text-slate-900 dark:text-white leading-tight">
              Comece a investir
              <br />
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                com segurança
              </span>
            </h1>

            <p className="text-xl text-slate-600 dark:text-slate-300 leading-relaxed">
              Ganhe até 2% ao dia com rendimentos automáticos e saques instantâneos.
            </p>

            <div className="space-y-4 pt-4">
              {[
                { icon: CheckCircleIcon, text: "Rendimento diário de 2%", color: "text-green-500" },
                { icon: CheckCircleIcon, text: "Saques ilimitados e instantâneos", color: "text-blue-500" },
                { icon: CheckCircleIcon, text: "Ganhe 10% por indicação", color: "text-purple-500" },
                { icon: CheckCircleIcon, text: "Plataforma 100% segura", color: "text-indigo-500" },
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <item.icon className={`h-6 w-6 ${item.color}`} />
                  <span className="text-lg font-medium text-slate-700 dark:text-slate-200">{item.text}</span>
                </div>
              ))}
            </div>

            <div className="pt-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400">
                <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                <span className="font-semibold">{usersCount.toLocaleString()} investidores ativos</span>
              </div>
            </div>
          </div>
        </div>

        {/* Lado Direito - Formulário */}
        <div className="w-full">
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-2xl shadow-2xl p-8 space-y-6">
            {/* Header Mobile */}
            <div className="lg:hidden text-center mb-6">
              <div className="flex items-center justify-center gap-3 mb-4">
                <div className="h-12 w-12 grid place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg">
                  <SparklesIcon className="h-6 w-6 text-white" />
                </div>
                <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  InvestFutura
                </span>
              </div>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">Criar Conta</h2>
              <p className="text-slate-600 dark:text-slate-400">Preencha seus dados para começar</p>
            </div>

            {sponsorCode && (
              <div className="p-4 rounded-xl bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800">
                <p className="text-sm font-medium text-purple-900 dark:text-purple-300">
                  🎉 Indicado por: <span className="font-bold">{sponsorCode}</span>
                </p>
              </div>
            )}

            {!sponsorCode && (
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Código de Indicação (Opcional)
                </label>
                <input
                  type="text"
                  value={sponsorCode}
                  onChange={(e) => setSponsorCode(e.target.value.toUpperCase())}
                  placeholder="Ex: FUT1A2B3C"
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
            )}

            {erro && (
              <div className="p-4 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800">
                <p className="text-sm font-medium text-red-900 dark:text-red-300">{erro}</p>
              </div>
            )}

            {sucesso && (
              <div className="p-4 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
                <p className="text-sm font-medium text-green-900 dark:text-green-300">
                  Cadastro realizado com sucesso! Redirecionando...
                </p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Nome */}
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Nome Completo
                </label>
                <div className="relative">
                  <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <input
                    type="text"
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    placeholder="Seu nome completo"
                    className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {/* E-mail */}
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">E-mail</label>
                <div className="relative">
                  <EnvelopeIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seu@email.com"
                    className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {/* Telefone */}
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Telefone/WhatsApp
                </label>
                <div className="relative">
                  <PhoneIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <input
                    type="tel"
                    value={telefone}
                    onChange={(e) => setTelefone(e.target.value)}
                    placeholder="(11) 99999-9999"
                    className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {/* Senha */}
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Senha</label>
                <div className="relative">
                  <LockClosedIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <input
                    type={mostrarSenha ? "text" : "password"}
                    value={senha}
                    onChange={(e) => setSenha(e.target.value)}
                    placeholder="Mínimo 6 caracteres"
                    className="w-full pl-12 pr-12 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="button"
                    onClick={() => setMostrarSenha(!mostrarSenha)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {mostrarSenha ? <EyeSlashIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              {/* Confirmar Senha */}
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Confirmar Senha
                </label>
                <div className="relative">
                  <LockClosedIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                  <input
                    type={mostrarConfirmar ? "text" : "password"}
                    value={confirmarSenha}
                    onChange={(e) => setConfirmarSenha(e.target.value)}
                    placeholder="Digite a senha novamente"
                    className="w-full pl-12 pr-12 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="button"
                    onClick={() => setMostrarConfirmar(!mostrarConfirmar)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {mostrarConfirmar ? <EyeSlashIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-lg shadow-2xl shadow-indigo-500/50 transition-all"
              >
                Criar Conta Grátis
              </button>
            </form>

            <div className="text-center pt-4">
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Já tem uma conta?{" "}
                <Link href="/" className="font-semibold text-indigo-600 dark:text-indigo-400 hover:underline">
                  Fazer Login
                </Link>
              </p>
            </div>

            <p className="text-xs text-center text-slate-500 dark:text-slate-400 pt-4">
              Ao se cadastrar, você concorda com nossos{" "}
              <a href="#" className="underline hover:text-slate-700 dark:hover:text-slate-300">
                Termos de Uso
              </a>{" "}
              e{" "}
              <a href="#" className="underline hover:text-slate-700 dark:hover:text-slate-300">
                Política de Privacidade
              </a>
            </p>
          </div>
        </div>
      </div>
    </main>
  )
}
