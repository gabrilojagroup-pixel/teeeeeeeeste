"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  UserGroupIcon,
  ClipboardIcon,
  CheckIcon,
  ChartBarIcon,
  SparklesIcon,
  TrophyIcon,
  ArrowLeftIcon,
} from "@heroicons/react/24/solid"
import { useTheme } from "@/lib/theme-context"

type AffiliateLevel = {
  level: number
  percentage: number
  referrals: number
  totalEarned: number
}

type ReferralHistory = {
  id: number
  name: string
  date: string
  level: 1 | 2 | 3
  earned: number
}

export default function AfiliadosPage() {
  const router = useRouter()
  const { theme } = useTheme()
  const [copied, setCopied] = useState(false)
  const [usuario, setUsuario] = useState<any>(null)
  const [stats, setStats] = useState({
    nivel1: { referrals: 0, totalEarned: 0 },
    nivel2: { referrals: 0, totalEarned: 0 },
    nivel3: { referrals: 0, totalEarned: 0 },
  })

  useEffect(() => {
    const usuarioLogado = localStorage.getItem("usuarioLogado")
    if (!usuarioLogado) {
      router.push("/login")
      return
    }
    const user = JSON.parse(usuarioLogado)
    setUsuario(user)

    // Calculate real affiliate stats
    const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]")

    // Level 1 - direct referrals
    const nivel1Users = usuarios.filter((u: any) => u.sponsor === user.referralCode)

    // Level 2 - referrals of referrals
    let nivel2Users: any[] = []
    nivel1Users.forEach((l1: any) => {
      const l2 = usuarios.filter((u: any) => u.sponsor === l1.referralCode)
      nivel2Users = [...nivel2Users, ...l2]
    })

    // Level 3 - third level referrals
    let nivel3Users: any[] = []
    nivel2Users.forEach((l2: any) => {
      const l3 = usuarios.filter((u: any) => u.sponsor === l2.referralCode)
      nivel3Users = [...nivel3Users, ...l3]
    })

    setStats({
      nivel1: { referrals: nivel1Users.length, totalEarned: user.bonusRef || 0 },
      nivel2: { referrals: nivel2Users.length, totalEarned: 0 },
      nivel3: { referrals: nivel3Users.length, totalEarned: 0 },
    })
  }, [router])

  if (!usuario) return null

  const refCode = usuario.referralCode || ""
  const refLink = `${window.location.origin}/register?ref=${refCode}`
  const totalEarned = stats.nivel1.totalEarned + stats.nivel2.totalEarned + stats.nivel3.totalEarned

  const copyRef = () => {
    navigator.clipboard.writeText(refLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-slate-900 text-slate-900 dark:text-slate-50 transition-all duration-500">
      {/* Header */}
      <header className="border-b border-slate-200/50 dark:border-slate-800/50 backdrop-blur-xl bg-white/50 dark:bg-slate-900/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.back()}
              className="p-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
            >
              <ArrowLeftIcon className="h-5 w-5" />
            </button>
            <div className="h-11 w-11 grid place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg shadow-indigo-500/50">
              <SparklesIcon className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent">
              Programa de Afiliados
            </span>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Hero Section */}
        <div className="rounded-3xl bg-gradient-to-br from-purple-600 via-pink-600 to-orange-600 p-8 text-white shadow-2xl shadow-purple-500/30">
          <div className="flex items-center gap-3 mb-4">
            <UserGroupIcon className="h-8 w-8" />
            <h1 className="text-3xl font-bold">Ganhe Dinheiro Indicando Amigos</h1>
          </div>
          <p className="text-lg text-white/90 mb-6 max-w-3xl">
            Receba comissões de até 3 níveis! Quanto mais sua rede cresce, mais você ganha. Sistema totalmente
            automático e transparente.
          </p>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="rounded-2xl bg-white/10 backdrop-blur-xl p-5 border border-white/20">
              <p className="text-sm text-white/80 mb-1">Nível 1 - Direto</p>
              <p className="text-4xl font-bold">15%</p>
              <p className="text-sm text-white/80 mt-1">de cada depósito</p>
            </div>
            <div className="rounded-2xl bg-white/10 backdrop-blur-xl p-5 border border-white/20">
              <p className="text-sm text-white/80 mb-1">Nível 2 - Indireto</p>
              <p className="text-4xl font-bold">3%</p>
              <p className="text-sm text-white/80 mt-1">dos indicados deles</p>
            </div>
            <div className="rounded-2xl bg-white/10 backdrop-blur-xl p-5 border border-white/20">
              <p className="text-sm text-white/80 mb-1">Nível 3 - Rede</p>
              <p className="text-4xl font-bold">2%</p>
              <p className="text-sm text-white/80 mt-1">da rede completa</p>
            </div>
          </div>
        </div>

        {/* Stats Dashboard */}
        <div className="grid md:grid-cols-4 gap-6">
          <div className="md:col-span-1 rounded-3xl bg-gradient-to-br from-green-500 to-emerald-600 p-6 text-white shadow-2xl shadow-green-500/30">
            <div className="flex items-center gap-2 mb-3">
              <ChartBarIcon className="h-5 w-5 opacity-80" />
              <span className="text-sm font-medium opacity-90">Total Ganho</span>
            </div>
            <p className="text-4xl font-bold mb-2">R$ {totalEarned.toFixed(2)}</p>
            <p className="text-sm opacity-80">Todas as comissões</p>
          </div>

          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <div className="h-3 w-3 rounded-full bg-purple-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Nível 1 (15%)</span>
            </div>
            <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">{stats.nivel1.referrals}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">R$ {stats.nivel1.totalEarned.toFixed(2)} ganho</p>
          </div>

          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <div className="h-3 w-3 rounded-full bg-pink-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Nível 2 (3%)</span>
            </div>
            <p className="text-3xl font-bold text-pink-600 dark:text-pink-400">{stats.nivel2.referrals}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">R$ {stats.nivel2.totalEarned.toFixed(2)} ganho</p>
          </div>

          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <div className="h-3 w-3 rounded-full bg-orange-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Nível 3 (2%)</span>
            </div>
            <p className="text-3xl font-bold text-orange-600 dark:text-orange-400">{stats.nivel3.referrals}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">R$ {stats.nivel3.totalEarned.toFixed(2)} ganho</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Link de Afiliado */}
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <ClipboardIcon className="h-6 w-6 text-purple-500" />
              Seu Link de Afiliado
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
              Compartilhe este link nas redes sociais, grupos ou com amigos. Cada vez que alguém se cadastrar e fazer um
              depósito usando seu link, você recebe comissão automaticamente!
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Seu Código Exclusivo
                </label>
                <div className="flex gap-3">
                  <input
                    readOnly
                    value={refCode}
                    className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 text-lg font-mono font-bold text-center select-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Link Completo
                </label>
                <div className="flex gap-3">
                  <input
                    readOnly
                    value={refLink}
                    className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 text-sm font-mono select-all"
                  />
                  <button
                    onClick={copyRef}
                    className="px-6 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold flex items-center gap-2 transition-all shadow-lg shadow-purple-500/30"
                  >
                    {copied ? (
                      <>
                        <CheckIcon className="h-5 w-5" />
                        Copiado!
                      </>
                    ) : (
                      <>
                        <ClipboardIcon className="h-5 w-5" />
                        Copiar
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 rounded-xl bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800">
              <p className="text-sm font-bold text-purple-900 dark:text-purple-300 mb-2">💡 Dica Pro:</p>
              <p className="text-sm text-purple-800 dark:text-purple-400">
                Compartilhe seu link em grupos de investimentos, stories do Instagram, status do WhatsApp e em posts
                sobre renda extra. Quanto mais visibilidade, mais ganhos!
              </p>
            </div>
          </div>

          {/* Como Funciona */}
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <TrophyIcon className="h-6 w-6 text-amber-500" />
              Como Funciona o Sistema
            </h3>

            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-gradient-to-r from-purple-100 to-purple-50 dark:from-purple-900/30 dark:to-purple-900/10 border border-purple-200 dark:border-purple-800">
                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-purple-600 text-white grid place-items-center font-bold text-sm flex-shrink-0">
                    1
                  </div>
                  <div>
                    <p className="font-bold text-purple-900 dark:text-purple-300 mb-1">Nível 1 - Seus Indicados</p>
                    <p className="text-sm text-purple-800 dark:text-purple-400">
                      Ganhe <strong>15%</strong> de cada depósito que seus indicados diretos fizerem. Se alguém
                      depositar R$ 1.000, você recebe R$ 150 na hora!
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-gradient-to-r from-pink-100 to-pink-50 dark:from-pink-900/30 dark:to-pink-900/10 border border-pink-200 dark:border-pink-800">
                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-pink-600 text-white grid place-items-center font-bold text-sm flex-shrink-0">
                    2
                  </div>
                  <div>
                    <p className="font-bold text-pink-900 dark:text-pink-300 mb-1">Nível 2 - Indicados dos Indicados</p>
                    <p className="text-sm text-pink-800 dark:text-pink-400">
                      Ganhe <strong>3%</strong> dos depósitos que os indicados dos seus indicados fizerem. Sua rede
                      trabalhando por você!
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-gradient-to-r from-orange-100 to-orange-50 dark:from-orange-900/30 dark:to-orange-900/10 border border-orange-200 dark:border-orange-800">
                <div className="flex items-start gap-3">
                  <div className="h-8 w-8 rounded-full bg-orange-600 text-white grid place-items-center font-bold text-sm flex-shrink-0">
                    3
                  </div>
                  <div>
                    <p className="font-bold text-orange-900 dark:text-orange-300 mb-1">Nível 3 - Rede Completa</p>
                    <p className="text-sm text-orange-800 dark:text-orange-400">
                      Ganhe <strong>2%</strong> de toda a sua rede de terceiro nível. Renda passiva automática e
                      escalável!
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
              <p className="text-sm font-bold text-green-900 dark:text-green-300 mb-2">✨ Pagamento Instantâneo</p>
              <p className="text-sm text-green-800 dark:text-green-400">
                Todas as comissões são creditadas automaticamente na sua conta. Sem burocracias, sem espera!
              </p>
            </div>
          </div>
        </div>

        {/* Histórico de Indicações */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
          <h3 className="text-xl font-bold mb-6">Histórico de Comissões</h3>

          <div className="overflow-x-auto">
            {stats.nivel1.referrals === 0 && stats.nivel2.referrals === 0 && stats.nivel3.referrals === 0 ? (
              <p className="text-center text-slate-500 dark:text-slate-400 py-8">
                Você ainda não possui indicados. Compartilhe seu link para começar a ganhar!
              </p>
            ) : (
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Você tem {stats.nivel1.referrals + stats.nivel2.referrals + stats.nivel3.referrals} indicados em sua
                rede. Continue compartilhando seu link para aumentar seus ganhos!
              </p>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
