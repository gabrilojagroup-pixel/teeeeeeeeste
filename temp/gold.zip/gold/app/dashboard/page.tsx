"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import {
  ClipboardIcon,
  CheckIcon,
  ArrowTrendingUpIcon,
  UserGroupIcon,
  WalletIcon,
  TrophyIcon,
  BellIcon,
  ArrowRightOnRectangleIcon,
  SparklesIcon,
  CalendarIcon,
  UserCircleIcon,
  SunIcon,
  MoonIcon,
  ArrowUpIcon,
  ArrowDownIcon,
} from "@heroicons/react/24/solid"
import { useTheme } from "@/lib/theme-context"

type Notification = {
  id: number
  text: string
  time: string
}

type User = {
  id: number
  nome: string
  email: string
  telefone: string
  senha: string
  sponsor: string
  saldo: number
  rendimento: number
  bonusRef: number
  indicados: number
  nivel: number
  dataCriacao: string
  referralCode?: string
}

export default function Dashboard() {
  const router = useRouter()
  const { theme, toggleTheme } = useTheme()
  const [usuario, setUsuario] = useState<User | null>(null)
  const [usersOnline, setUsersOnline] = useState(2847)
  const [notifications, setNotifications] = useState<Notification[]>([])

  const handleLogout = () => {
    localStorage.removeItem("usuarioLogado")
    router.push("/login")
  }

  useEffect(() => {
    const usuarioLogado = localStorage.getItem("usuarioLogado")
    if (!usuarioLogado) {
      router.push("/login")
      return
    }
    setUsuario(JSON.parse(usuarioLogado))
  }, [router])

  useEffect(() => {
    const t = setInterval(() => setUsersOnline((n) => n + Math.floor(Math.random() * 5 - 2)), 6000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    if (!usuario) return

    const processYields = () => {
      const investimentos = JSON.parse(localStorage.getItem("investimentos") || "[]")
      let totalYield = 0
      let updated = false

      const now = new Date()

      investimentos.forEach((inv: any) => {
        if (!inv.active || inv.userId !== usuario.id) return

        const lastYieldDate = new Date(inv.lastYield)
        const diffTime = now.getTime() - lastYieldDate.getTime()
        const diffHours = diffTime / (1000 * 60 * 60)

        if (diffHours >= 24) {
          const yieldAmount = (inv.amount * inv.dailyReturn) / 100
          totalYield += yieldAmount
          inv.lastYield = now.toISOString()
          updated = true

          console.log("[v0] Processed yield:", {
            investment: inv.planName,
            amount: yieldAmount,
            userId: usuario.id,
          })
        }
      })

      if (updated && totalYield > 0) {
        localStorage.setItem("investimentos", JSON.stringify(investimentos))

        const usuarioAtualizado = {
          ...usuario,
          saldo: usuario.saldo + totalYield,
          rendimento: usuario.rendimento + totalYield,
        }

        setUsuario(usuarioAtualizado)
        localStorage.setItem("usuarioLogado", JSON.stringify(usuarioAtualizado))

        const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]")
        const index = usuarios.findIndex((u: User) => u.id === usuario.id)
        if (index !== -1) {
          usuarios[index] = usuarioAtualizado
          localStorage.setItem("usuarios", JSON.stringify(usuarios))
        }

        const transacoes = JSON.parse(localStorage.getItem("transacoes") || "[]")
        transacoes.unshift({
          id: Date.now(),
          tipo: "RENDIMENTO",
          valor: totalYield,
          status: "APROVADO",
          data: now.toISOString(),
          descricao: "Rendimento automático diário de investimentos",
        })
        localStorage.setItem("transacoes", JSON.stringify(transacoes))

        const newNotif: Notification = {
          id: Date.now(),
          text: `💰 Rendimento creditado: +R$ ${totalYield.toFixed(2)}`,
          time: "agora",
        }
        setNotifications((prev) => [newNotif, ...prev.slice(0, 4)])
      }
    }

    processYields()
    const interval = setInterval(processYields, 60000) // Check every minute

    return () => clearInterval(interval)
  }, [usuario])

  useEffect(() => {
    if (!usuario) return

    const processAffiliateBonuses = () => {
      // This would be triggered when someone in your network makes a deposit/investment
      // For now, simulated - in production, this would be triggered by actual events
    }

    processAffiliateBonuses()
  }, [usuario])

  const copyRef = () => {
    if (!usuario?.referralCode) return
    const refLink = `${window.location.origin}/register?ref=${usuario.referralCode}`
    navigator.clipboard.writeText(refLink)
    setCopiado(true)
    setTimeout(() => setCopiado(false), 2000)
  }

  const [copiado, setCopiado] = useState(false)

  if (!usuario) return null

  const refLink = usuario.referralCode ? `${window.location.origin}/register?ref=${usuario.referralCode}` : ""

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-slate-900 text-slate-900 dark:text-slate-50 transition-all duration-500">
      {/* Header */}
      <header className="border-b border-slate-200/50 dark:border-slate-800/50 backdrop-blur-xl bg-white/50 dark:bg-slate-900/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-11 w-11 grid place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg shadow-indigo-500/50">
              <SparklesIcon className="h-6 w-6 text-white" />
            </div>
            <div>
              <span className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent block">
                InvestFutura
              </span>
              <span className="text-xs text-slate-600 dark:text-slate-400">{usuario.nome}</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-sm font-medium">
              <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
              {usersOnline.toLocaleString()} online
            </div>

            <button
              onClick={toggleTheme}
              className="p-2.5 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
              aria-label="Alternar tema"
              title={theme === "dark" ? "Modo claro" : "Modo escuro"}
            >
              {theme === "dark" ? (
                <SunIcon className="h-5 w-5 text-amber-500" />
              ) : (
                <MoonIcon className="h-5 w-5 text-indigo-600" />
              )}
            </button>

            <button
              onClick={handleLogout}
              className="p-2.5 rounded-xl bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 hover:bg-red-200 dark:hover:bg-red-900/50 transition-colors"
              title="Sair"
            >
              <ArrowRightOnRectangleIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Hero Stats */}
        <div className="grid md:grid-cols-4 gap-6">
          <div className="md:col-span-1 rounded-3xl bg-gradient-to-br from-indigo-500 to-purple-600 p-6 text-white shadow-2xl shadow-indigo-500/30">
            <div className="flex items-center gap-2 mb-3">
              <WalletIcon className="h-5 w-5 opacity-80" />
              <span className="text-sm font-medium opacity-90">Saldo Total</span>
            </div>
            <p className="text-4xl font-bold mb-2">R$ {usuario.saldo.toFixed(2)}</p>
            <p className="text-sm opacity-80">
              Nível {usuario.nivel} • {usuario.indicados} indicados
            </p>
          </div>

          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <ArrowTrendingUpIcon className="h-5 w-5 text-green-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Rendimento 24h</span>
            </div>
            <p className="text-3xl font-bold text-green-600 dark:text-green-400">+R$ {usuario.rendimento.toFixed(2)}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Automático</p>
          </div>

          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <UserGroupIcon className="h-5 w-5 text-purple-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Bônus Afiliados</span>
            </div>
            <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">R$ {usuario.bonusRef.toFixed(2)}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Até 15% por indicação</p>
          </div>

          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <TrophyIcon className="h-5 w-5 text-amber-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Indicações</span>
            </div>
            <p className="text-3xl font-bold text-amber-600 dark:text-amber-400">{usuario.indicados}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Indicados ativos</p>
          </div>
        </div>

        <div className="grid md:grid-cols-6 gap-4">
          <Link
            href="/depositar"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-green-500/10 to-emerald-500/10 dark:from-green-900/20 dark:to-emerald-900/20 backdrop-blur-xl p-5 hover:scale-105 transition-all text-left group"
          >
            <ArrowDownIcon className="h-8 w-8 text-green-600 dark:text-green-400 mb-3 group-hover:scale-110 transition-transform" />
            <p className="font-bold text-lg mb-1">Depositar</p>
            <p className="text-sm text-slate-600 dark:text-slate-400">PIX instantâneo</p>
          </Link>

          <Link
            href="/sacar"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-purple-500/10 to-pink-500/10 dark:from-purple-900/20 dark:to-pink-900/20 backdrop-blur-xl p-5 hover:scale-105 transition-all text-left group"
          >
            <ArrowUpIcon className="h-8 w-8 text-purple-600 dark:text-purple-400 mb-3 group-hover:scale-110 transition-transform" />
            <p className="font-bold text-lg mb-1">Sacar</p>
            <p className="text-sm text-slate-600 dark:text-slate-400">Receba em 30s</p>
          </Link>

          <Link
            href="/afiliados"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-purple-500/10 to-pink-500/10 dark:from-purple-900/20 dark:to-pink-900/20 backdrop-blur-xl p-5 hover:scale-105 transition-all text-left group"
          >
            <UserGroupIcon className="h-8 w-8 text-purple-600 dark:text-purple-400 mb-3 group-hover:scale-110 transition-transform" />
            <p className="font-bold text-lg mb-1">Afiliados</p>
            <p className="text-sm text-slate-600 dark:text-slate-400">Ganhe até 15%</p>
          </Link>

          <Link
            href="/checkin"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-green-500/10 to-emerald-500/10 dark:from-green-900/20 dark:to-emerald-500/10 backdrop-blur-xl p-5 hover:scale-105 transition-all text-left group"
          >
            <CalendarIcon className="h-8 w-8 text-green-600 dark:text-green-400 mb-3 group-hover:scale-110 transition-transform" />
            <p className="font-bold text-lg mb-1">Check-in</p>
            <p className="text-sm text-slate-600 dark:text-slate-400">R$ 1,00 grátis</p>
          </Link>

          <Link
            href="/planos"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-amber-500/10 to-orange-500/10 dark:from-amber-900/20 dark:to-orange-900/20 backdrop-blur-xl p-5 hover:scale-105 transition-all text-left group"
          >
            <TrophyIcon className="h-8 w-8 text-amber-600 dark:text-amber-400 mb-3 group-hover:scale-110 transition-transform" />
            <p className="font-bold text-lg mb-1">Planos</p>
            <p className="text-sm text-slate-600 dark:text-slate-400">Invista agora</p>
          </Link>

          <Link
            href="/perfil"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-blue-500/10 to-indigo-500/10 dark:from-blue-900/20 dark:to-indigo-900/20 backdrop-blur-xl p-5 hover:scale-105 transition-all text-left group"
          >
            <UserCircleIcon className="h-8 w-8 text-blue-600 dark:text-blue-400 mb-3 group-hover:scale-110 transition-transform" />
            <p className="font-bold text-lg mb-1">Perfil</p>
            <p className="text-sm text-slate-600 dark:text-slate-400">Seus dados</p>
          </Link>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Coluna Esquerda */}
          <div className="lg:col-span-2 space-y-6">
            {/* Link de Afiliado */}
            <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-purple-500/10 to-pink-500/10 dark:from-purple-900/20 dark:to-pink-900/20 backdrop-blur-xl p-6">
              <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
                <UserGroupIcon className="h-6 w-6 text-purple-500" />
                Sistema Multi-Nível Revolucionário
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                Construa sua rede e ganhe comissões automáticas de até 3 níveis. Quanto maior sua rede, maior seus
                ganhos passivos! Tecnologia de ponta para maximizar seus lucros.
              </p>

              <div className="flex gap-3 mb-4">
                <input
                  readOnly
                  value={refLink}
                  className="flex-1 rounded-xl border border-purple-300 dark:border-purple-700 bg-white dark:bg-slate-800 px-4 py-3 text-sm font-mono select-all"
                />
                <button
                  onClick={copyRef}
                  className="px-5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold flex items-center gap-2 transition-all shadow-lg shadow-purple-500/30"
                >
                  {copiado ? (
                    <>
                      <CheckIcon className="h-5 w-5" />
                      Copiado!
                    </>
                  ) : (
                    <>
                      <ClipboardIcon className="h-5 w-5" />
                      Copiar
                    </>
                  )}
                </button>
              </div>

              <Link
                href="/afiliados"
                className="w-full rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 py-3 text-white font-bold shadow-lg shadow-purple-500/30 transition-all"
              >
                Ver Detalhes do Programa →
              </Link>
            </div>

            {/* PIX Instantâneo */}
            <div className="mt-6 p-4 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 border border-blue-200 dark:border-blue-800">
              <p className="text-sm font-medium text-blue-900 dark:text-blue-300 mb-2">
                💎 PIX Instantâneo - Liberação automática
              </p>
              <code className="text-xs text-blue-700 dark:text-blue-400 break-all select-all">
                00020126580014br.gov.bcb.pix0136f47ac10b-5c4b-4e8d-8a1f2-3e4f5a6b7c8d52040000530398654071247.825802BR5925InvestFutura
                LTDA6009SAO PAULO62070503***6304B7C3
              </code>
            </div>
          </div>

          {/* Coluna Direita - Notificações */}
          <div className="space-y-6">
            <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <BellIcon className="h-6 w-6 text-indigo-500" />
                Atividade Recente
              </h3>

              <div className="space-y-3">
                {notifications.length === 0 ? (
                  <p className="text-sm text-slate-500 dark:text-slate-400 text-center py-4">
                    Nenhuma notificação ainda
                  </p>
                ) : (
                  notifications.map((notif) => (
                    <div
                      key={notif.id}
                      className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                    >
                      <p className="text-sm font-medium mb-1">{notif.text}</p>
                      <p className="text-xs text-slate-500">{notif.time}</p>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-green-500/10 to-emerald-500/10 dark:from-green-900/20 dark:to-emerald-950/20 backdrop-blur-xl p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <CalendarIcon className="h-6 w-6 text-green-500" />
                Check-in Diário Automático
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                Ganhe R$ 1,00 grátis todos os dias direto no seu saldo! Sistema totalmente automatizado. Não perca
                nenhum dia e acumule R$ 30,00 por mês.
              </p>
              <Link
                href="/checkin"
                className="w-full rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 py-3 text-white font-bold shadow-lg shadow-green-500/30 transition-all"
              >
                Fazer Check-in Agora →
              </Link>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
