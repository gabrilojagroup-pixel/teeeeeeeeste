"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  SparklesIcon,
  ArrowLeftIcon,
  CreditCardIcon,
  CheckCircleIcon,
  ClockIcon,
  ShieldCheckIcon,
  DocumentDuplicateIcon,
} from "@heroicons/react/24/solid"
import { cleanDocument, validateDocument, formatCPF, formatPhone } from "@/lib/utils"
import { getGlobalConfig } from "@/lib/global-config"
import { processAffiliateBonus } from "@/lib/affiliate-system"

type User = {
  id: number
  nome: string
  email: string
  telefone: string
  documento: string
  saldo: number
  sponsor?: string
}

export default function DepositarPage() {
  const router = useRouter()
  const [usuario, setUsuario] = useState<User | null>(null)
  const [valor, setValor] = useState("")
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [pixData, setPixData] = useState<any>(null)
  const [transactionId, setTransactionId] = useState<string>("")
  const [identifier, setIdentifier] = useState<string>("")

  const [nome, setNome] = useState("")
  const [cpf, setCpf] = useState("")
  const [telefone, setTelefone] = useState("")

  const [config, setConfig] = useState<any>({
    limites: { depositoMinimo: 30, saqueMinimo: 30 },
    comissoes: { nivel1: 15 },
  })

  useEffect(() => {
    const loadedConfig = getGlobalConfig()
    if (loadedConfig && loadedConfig.limites) {
      setConfig(loadedConfig)
    }
  }, [])

  const minDeposit = config?.limites?.depositoMinimo || 30

  useEffect(() => {
    const usuarioLogado = localStorage.getItem("usuarioLogado")
    if (!usuarioLogado) {
      router.push("/login")
      return
    }
    const user = JSON.parse(usuarioLogado)
    setUsuario(user)

    setNome(user.nome || "")
    setCpf(user.documento || "")
    setTelefone(user.telefone || "")
  }, [router])

  useEffect(() => {
    if (!identifier) return

    const checkInterval = setInterval(() => {
      const pendingDeposits = JSON.parse(localStorage.getItem("pendingDeposits") || "[]")
      const completedDeposit = pendingDeposits.find((d: any) => d.identifier === identifier && d.status === "COMPLETED")

      if (completedDeposit) {
        const amount = Number(valor)

        const bonuses = processAffiliateBonus(amount, usuario!.email)

        const usuarioAtualizado = {
          ...usuario!,
          saldo: usuario!.saldo + amount,
        }

        localStorage.setItem("usuarioLogado", JSON.stringify(usuarioAtualizado))

        const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]")
        const index = usuarios.findIndex((u: any) => u.id === usuario!.id)
        if (index !== -1) {
          usuarios[index] = usuarioAtualizado
          localStorage.setItem("usuarios", JSON.stringify(usuarios))
        }

        const transacoes = JSON.parse(localStorage.getItem("transacoes") || "[]")
        transacoes.unshift({
          id: Date.now(),
          tipo: "DEPOSITO",
          valor: amount,
          status: "APROVADO",
          data: new Date().toISOString(),
          descricao: `Depósito via PIX - PoseidonPay${bonuses.nivel1 ? ` | Bônus Nível 1: R$ ${bonuses.nivel1.amount.toFixed(2)}` : ""}`,
          identifier,
        })
        localStorage.setItem("transacoes", JSON.stringify(transacoes))

        const updatedPending = pendingDeposits.filter((d: any) => d.identifier !== identifier)
        localStorage.setItem("pendingDeposits", JSON.stringify(updatedPending))

        clearInterval(checkInterval)
        setSuccess(true)
        setTimeout(() => router.push("/dashboard"), 2000)
      }
    }, 2000)

    return () => clearInterval(checkInterval)
  }, [identifier, valor, usuario, router])

  const handleGeneratePix = async () => {
    if (!usuario) return

    const amount = Number(valor)
    if (!amount || amount < minDeposit) {
      alert(`Valor mínimo de depósito é R$ ${minDeposit.toFixed(2)}`)
      return
    }

    if (!nome || !cpf || !telefone) {
      alert("Preencha todos os campos obrigatórios: Nome, CPF e Telefone")
      return
    }

    if (!validateDocument(cpf)) {
      alert("CPF inválido! Verifique o número digitado.")
      return
    }

    const cleanCPF = cleanDocument(cpf)
    const cleanPhone = cleanDocument(telefone)

    if (cleanPhone.length < 10 || cleanPhone.length > 11) {
      alert("Telefone inválido! Digite o DDD + número (10 ou 11 dígitos)")
      return
    }

    setLoading(true)

    try {
      const response = await fetch("/api/pix/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount,
          userEmail: usuario.email,
          userName: nome,
          userDocument: cleanCPF,
          userPhone: cleanPhone,
        }),
      })

      const result = await response.json()

      if (result.success) {
        setPixData(result.data.pix)
        setTransactionId(result.data.transactionId)
        setIdentifier(result.identifier)

        const pendingDeposits = JSON.parse(localStorage.getItem("pendingDeposits") || "[]")
        pendingDeposits.push({
          identifier: result.identifier,
          transactionId: result.data.transactionId,
          amount,
          userId: usuario.id,
          status: "PENDING",
          createdAt: new Date().toISOString(),
        })
        localStorage.setItem("pendingDeposits", JSON.stringify(pendingDeposits))
      } else {
        throw new Error(result.error)
      }
    } catch (error: any) {
      console.error("Error generating PIX:", error)
      alert("Erro ao gerar PIX: " + error.message)
    } finally {
      setLoading(false)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    alert("Código PIX copiado!")
  }

  if (!usuario) return null

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-slate-900 text-slate-900 dark:text-slate-50 transition-all duration-500">
      <header className="border-b border-slate-200/50 dark:border-slate-800/50 backdrop-blur-xl bg-white/50 dark:bg-slate-900/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.back()}
              className="p-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
            >
              <ArrowLeftIcon className="h-5 w-5" />
            </button>
            <div className="h-11 w-11 grid place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg shadow-indigo-500/50">
              <SparklesIcon className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent">
              Depositar Fundos
            </span>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">
        <div className="rounded-3xl bg-gradient-to-br from-green-600 via-emerald-600 to-teal-600 p-8 text-white shadow-2xl shadow-green-500/30">
          <div className="flex items-center gap-3 mb-4">
            <CreditCardIcon className="h-10 w-10" />
            <h1 className="text-4xl font-bold">Depósito Instantâneo</h1>
          </div>
          <p className="text-lg text-white/90 mb-6">
            Adicione fundos à sua conta em segundos via PIX com a tecnologia PoseidonPay. Processamento automático e
            100% seguro com criptografia de ponta a ponta.
          </p>
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2 bg-white/20 backdrop-blur-xl px-4 py-2 rounded-full">
              <CheckCircleIcon className="h-5 w-5" />
              <span className="font-semibold">PIX Instantâneo</span>
            </div>
            <div className="flex items-center gap-2 bg-white/20 backdrop-blur-xl px-4 py-2 rounded-full">
              <ShieldCheckIcon className="h-5 w-5" />
              <span className="font-semibold">100% Seguro</span>
            </div>
            <div className="flex items-center gap-2 bg-white/20 backdrop-blur-xl px-4 py-2 rounded-full">
              <ClockIcon className="h-5 w-5" />
              <span className="font-semibold">Crédito Imediato</span>
            </div>
          </div>
        </div>

        {success ? (
          <div className="rounded-3xl border border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20 p-12 text-center">
            <CheckCircleIcon className="h-20 w-20 text-green-600 dark:text-green-400 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-green-900 dark:text-green-300 mb-2">Pagamento Confirmado!</h2>
            <p className="text-lg text-green-700 dark:text-green-400">
              Seu saldo foi atualizado. Redirecionando para o dashboard...
            </p>
          </div>
        ) : pixData ? (
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-8">
            <h3 className="text-2xl font-bold mb-6">Pague com PIX</h3>

            <div className="space-y-6">
              {pixData.image && (
                <div className="flex justify-center p-6 bg-white dark:bg-slate-800 rounded-2xl">
                  <img src={pixData.image || "/placeholder.svg"} alt="QR Code PIX" className="w-64 h-64" />
                </div>
              )}

              <div className="p-6 rounded-xl bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800">
                <h4 className="font-bold text-indigo-900 dark:text-indigo-300 mb-4">Código PIX Copia e Cola:</h4>
                <div className="relative">
                  <code className="block p-4 rounded-lg bg-white dark:bg-slate-800 text-indigo-900 dark:text-indigo-300 font-mono text-xs break-all select-all">
                    {pixData.code}
                  </code>
                  <button
                    onClick={() => copyToClipboard(pixData.code)}
                    className="absolute top-2 right-2 p-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition-colors"
                  >
                    <DocumentDuplicateIcon className="h-5 w-5" />
                  </button>
                </div>
              </div>

              <div className="p-6 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
                <div className="flex items-center gap-3 mb-3">
                  <div className="h-5 w-5 border-4 border-green-500/30 border-t-green-500 rounded-full animate-spin" />
                  <p className="font-bold text-green-900 dark:text-green-300">Aguardando pagamento...</p>
                </div>
                <p className="text-4xl font-bold text-green-600 dark:text-green-400">R$ {Number(valor).toFixed(2)}</p>
                <p className="text-sm text-green-700 dark:text-green-400 mt-2">
                  Aguardando confirmação de pagamento via webhook PoseidonPay. Assim que o pagamento for confirmado, seu
                  saldo será creditado automaticamente!
                </p>
              </div>

              <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
                <p className="text-sm text-blue-900 dark:text-blue-300">
                  <strong>💎 Como funciona:</strong> Abra seu app de pagamentos, escaneie o QR Code ou copie o código
                  PIX. Assim que o pagamento for confirmado pela PoseidonPay, você receberá uma notificação e seu saldo
                  será creditado instantaneamente via webhook!
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-8">
            <h3 className="text-2xl font-bold mb-6">Informações do Depósito</h3>

            <div className="space-y-6">
              <div className="p-6 rounded-xl bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
                <h4 className="font-bold text-blue-900 dark:text-blue-300 mb-4">Dados Obrigatórios para PIX</h4>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      Nome Completo *
                    </label>
                    <input
                      type="text"
                      value={nome}
                      onChange={(e) => setNome(e.target.value)}
                      placeholder="Seu nome completo"
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      disabled={loading}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">CPF *</label>
                    <input
                      type="text"
                      value={cpf}
                      onChange={(e) => {
                        const value = e.target.value
                        const cleaned = cleanDocument(value)
                        if (cleaned.length <= 11) {
                          setCpf(cleaned.length === 11 ? formatCPF(cleaned) : value)
                        }
                      }}
                      placeholder="000.000.000-00"
                      maxLength={14}
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      disabled={loading}
                    />
                    {cpf && !validateDocument(cpf) && cleanDocument(cpf).length === 11 && (
                      <p className="text-sm text-red-600 dark:text-red-400 mt-1">CPF inválido</p>
                    )}
                    {cpf && validateDocument(cpf) && (
                      <p className="text-sm text-green-600 dark:text-green-400 mt-1">✓ CPF válido</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      Telefone com DDD *
                    </label>
                    <input
                      type="text"
                      value={telefone}
                      onChange={(e) => {
                        const value = e.target.value
                        const cleaned = cleanDocument(value)
                        if (cleaned.length <= 11) {
                          setTelefone(cleaned.length >= 10 ? formatPhone(cleaned) : value)
                        }
                      }}
                      placeholder="(00) 00000-0000"
                      maxLength={15}
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      disabled={loading}
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Valor do Depósito (mínimo R$ {minDeposit.toFixed(2)}) *
                </label>
                <input
                  type="number"
                  value={valor}
                  onChange={(e) => setValor(e.target.value)}
                  placeholder="0.00"
                  min={minDeposit}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-6 py-4 text-2xl font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  disabled={loading}
                />
              </div>

              <button
                onClick={handleGeneratePix}
                disabled={
                  loading ||
                  !valor ||
                  Number(valor) < minDeposit ||
                  !nome ||
                  !cpf ||
                  !telefone ||
                  !validateDocument(cpf)
                }
                className="w-full rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 py-4 text-white text-lg font-bold shadow-2xl shadow-green-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
              >
                {loading ? (
                  <>
                    <div className="h-6 w-6 border-4 border-white/30 border-t-white rounded-full animate-spin" />
                    Gerando PIX Real...
                  </>
                ) : (
                  <>
                    <CheckCircleIcon className="h-6 w-6" />
                    Gerar PIX para Pagamento
                  </>
                )}
              </button>

              <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800">
                <p className="text-sm text-amber-900 dark:text-amber-300">
                  <strong>⚡ Como Funciona:</strong> Preencha todos os dados, clique em "Gerar PIX" e pague o QR Code
                  gerado pela PoseidonPay. Seu saldo só será creditado após confirmação REAL do pagamento via webhook.
                  {usuario?.sponsor && (
                    <span className="block mt-2 font-bold text-purple-600">
                      💰 Bônus: Seu indicador receberá {config.comissoes.nivel1}% de comissão automaticamente!
                    </span>
                  )}
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="grid md:grid-cols-3 gap-6">
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <CheckCircleIcon className="h-8 w-8 text-green-500 mb-3" />
            <h4 className="font-bold mb-2">Processamento Instantâneo</h4>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Seu depósito é confirmado em segundos via PoseidonPay
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <ShieldCheckIcon className="h-8 w-8 text-blue-500 mb-3" />
            <h4 className="font-bold mb-2">Segurança Máxima</h4>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Criptografia de ponta a ponta e conformidade PCI-DSS
            </p>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <CreditCardIcon className="h-8 w-8 text-purple-500 mb-3" />
            <h4 className="font-bold mb-2">Sem Taxas</h4>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Zero taxas de depósito. 100% do valor para você
            </p>
          </div>
        </div>
      </div>
    </main>
  )
}
