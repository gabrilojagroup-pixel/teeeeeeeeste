"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  SparklesIcon,
  ArrowLeftIcon,
  RocketLaunchIcon,
  BoltIcon,
  StarIcon,
  CheckCircleIcon,
  FireIcon,
} from "@heroicons/react/24/solid"
import { getGlobalConfig } from "@/lib/global-config"

type Plan = {
  id: number
  nome: string
  rendimentoDiario: number
  valorMinimo: number
  valorMaximo: number
  duracao: number
  retornoTotal: number
  features: string[]
  ativo: boolean
  premium?: boolean
}

export default function PlanosPage() {
  const router = useRouter()
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null)
  const [investmentAmount, setInvestmentAmount] = useState("")

  const [plans, setPlans] = useState<Plan[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    try {
      const config = getGlobalConfig()
      const activePlans = Array.isArray(config?.planos) ? config.planos.filter((p) => p.ativo) : []
      setPlans(activePlans)
    } catch (error) {
      console.error("[v0] Error loading plans:", error)
      setPlans([])
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    const handleConfigUpdate = () => {
      try {
        const config = getGlobalConfig()
        const activePlans = Array.isArray(config?.planos) ? config.planos.filter((p) => p.ativo) : []
        setPlans(activePlans)
      } catch (error) {
        console.error("[v0] Error updating plans:", error)
      }
    }

    window.addEventListener("globalConfigUpdated", handleConfigUpdate)
    return () => window.removeEventListener("globalConfigUpdated", handleConfigUpdate)
  }, [])

  const handleInvest = () => {
    if (!selectedPlan || !investmentAmount) return

    const plan = Array.isArray(plans) ? plans.find((p) => p.id === selectedPlan) : null
    const amount = Number(investmentAmount)

    if (!plan || amount < plan.valorMinimo || amount > plan.valorMaximo) {
      alert(`Valor deve estar entre R$ ${plan?.valorMinimo || 0} e R$ ${plan?.valorMaximo || 0}`)
      return
    }

    const usuarioLogado = localStorage.getItem("usuarioLogado")
    if (!usuarioLogado) {
      alert("Você precisa estar logado para investir")
      return
    }

    const usuario = JSON.parse(usuarioLogado)

    if (usuario.saldo < amount) {
      alert("Saldo insuficiente para este investimento")
      return
    }

    const novoInvestimento = {
      id: Date.now(),
      userId: usuario.id,
      planId: plan.id,
      planName: plan.nome,
      amount: amount,
      dailyReturn: plan.rendimentoDiario,
      startDate: new Date().toISOString(),
      lastYield: new Date().toISOString(),
      active: true,
    }

    const investimentos = JSON.parse(localStorage.getItem("investimentos") || "[]")
    investimentos.push(novoInvestimento)
    localStorage.setItem("investimentos", JSON.stringify(investimentos))

    const usuarioAtualizado = {
      ...usuario,
      saldo: usuario.saldo - amount,
    }

    localStorage.setItem("usuarioLogado", JSON.stringify(usuarioAtualizado))

    const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]")
    const index = usuarios.findIndex((u: any) => u.id === usuario.id)
    if (index !== -1) {
      usuarios[index] = usuarioAtualizado
      localStorage.setItem("usuarios", JSON.stringify(usuarios))
    }

    const transacoes = JSON.parse(localStorage.getItem("transacoes") || "[]")
    transacoes.unshift({
      id: Date.now(),
      tipo: "INVESTIMENTO",
      valor: amount,
      status: "APROVADO",
      data: new Date().toISOString(),
      descricao: `Investimento no plano ${plan.nome} - Rendimento de ${plan.rendimentoDiario}% ao dia`,
    })
    localStorage.setItem("transacoes", JSON.stringify(transacoes))

    alert(
      `Investimento de R$ ${amount.toFixed(2)} no plano ${plan.nome} realizado com sucesso! Os rendimentos começarão a ser creditados em 24h automaticamente.`,
    )
    router.push("/dashboard")
  }

  if (isLoading) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-slate-900 text-slate-900 dark:text-slate-50 transition-all duration-500">
        <div className="flex items-center justify-center h-screen">
          <div className="text-center">
            <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-indigo-600 border-r-transparent"></div>
            <p className="mt-4 text-lg font-semibold">Carregando planos...</p>
          </div>
        </div>
      </main>
    )
  }

  if (!plans || plans.length === 0) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-slate-900 text-slate-900 dark:text-slate-50 transition-all duration-500">
        <header className="border-b border-slate-200/50 dark:border-slate-800/50 backdrop-blur-xl bg-white/50 dark:bg-slate-900/50 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => router.back()}
                className="p-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
              >
                <ArrowLeftIcon className="h-5 w-5" />
              </button>
              <div className="h-11 w-11 grid place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg shadow-indigo-500/50">
                <SparklesIcon className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent">
                Planos de Investimento
              </span>
            </div>
          </div>
        </header>
        <div className="flex items-center justify-center min-h-[80vh]">
          <div className="text-center max-w-md px-6">
            <div className="h-16 w-16 mx-auto mb-4 rounded-full bg-slate-200 dark:bg-slate-800 grid place-items-center">
              <SparklesIcon className="h-8 w-8 text-slate-400" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Nenhum plano disponível</h2>
            <p className="text-slate-600 dark:text-slate-400 mb-6">
              Os planos de investimento estão sendo configurados. Por favor, volte mais tarde.
            </p>
            <button
              onClick={() => router.push("/dashboard")}
              className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold transition-colors"
            >
              Voltar ao Dashboard
            </button>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-slate-900 text-slate-900 dark:text-slate-50 transition-all duration-500">
      <header className="border-b border-slate-200/50 dark:border-slate-800/50 backdrop-blur-xl bg-white/50 dark:bg-slate-900/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.back()}
              className="p-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
            >
              <ArrowLeftIcon className="h-5 w-5" />
            </button>
            <div className="h-11 w-11 grid place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg shadow-indigo-500/50">
              <SparklesIcon className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent">
              Planos de Investimento
            </span>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Hero */}
        <div className="rounded-3xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-8 md:p-12 text-white shadow-2xl shadow-indigo-500/30">
          <div className="flex items-center gap-3 mb-4">
            <RocketLaunchIcon className="h-10 w-10" />
            <h1 className="text-4xl md:text-5xl font-bold">Invista e Multiplique Seu Patrimônio</h1>
          </div>
          <p className="text-lg md:text-xl text-white/90 max-w-3xl mb-6">
            Escolha o plano ideal para seu perfil e comece a lucrar hoje mesmo. Tecnologia de ponta, segurança máxima e
            rendimentos automáticos. O futuro do investimento está aqui.
          </p>
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center gap-2 bg-white/20 backdrop-blur-xl px-4 py-2 rounded-full border border-white/30">
              <BoltIcon className="h-5 w-5" />
              <span className="font-semibold">Rendimento Diário</span>
            </div>
            <div className="flex items-center gap-2 bg-white/20 backdrop-blur-xl px-4 py-2 rounded-full border border-white/30">
              <CheckCircleIcon className="h-5 w-5" />
              <span className="font-semibold">100% Seguro</span>
            </div>
            <div className="flex items-center gap-2 bg-white/20 backdrop-blur-xl px-4 py-2 rounded-full border border-white/30">
              <FireIcon className="h-5 w-5" />
              <span className="font-semibold">Saque Instantâneo</span>
            </div>
          </div>
        </div>

        {/* Plans Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array.isArray(plans) &&
            plans.map((plan) => (
              <div
                key={plan.id}
                className={`rounded-3xl border p-6 transition-all cursor-pointer overflow-hidden relative ${
                  selectedPlan === plan.id
                    ? "border-indigo-500 dark:border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 shadow-2xl shadow-indigo-500/30 scale-105"
                    : plan.premium
                      ? "border-amber-300 dark:border-amber-700 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 hover:scale-105"
                      : "border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 hover:scale-105"
                } backdrop-blur-xl`}
                onClick={() => setSelectedPlan(plan.id)}
              >
                {plan.premium && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-amber-600 to-orange-600 text-white text-xs font-bold shadow-lg z-10">
                    PREMIUM
                  </div>
                )}

                <div className="mb-4 h-32 bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-900/30 dark:to-purple-900/30 rounded-2xl flex items-center justify-center overflow-hidden">
                  <img
                    src={`/.jpg?key=j03qe&height=128&width=256&query=${encodeURIComponent(`${plan.nome} investment plan futuristic`)}`}
                    alt={plan.nome}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="mb-4">
                  <h3 className="text-2xl font-bold mb-2">{plan.nome}</h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold text-green-600 dark:text-green-400">
                      {plan.rendimentoDiario}%
                    </span>
                    <span className="text-sm text-slate-600 dark:text-slate-400">por dia</span>
                  </div>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                    {plan.retornoTotal}% em {plan.duracao} dias
                  </p>
                </div>

                <div className="space-y-2 mb-6">
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    <strong>Mínimo:</strong> R$ {plan.valorMinimo.toLocaleString()}
                  </p>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    <strong>Máximo:</strong> R$ {plan.valorMaximo.toLocaleString()}
                  </p>
                </div>

                <div className="space-y-2 mb-6">
                  {Array.isArray(plan.features) &&
                    plan.features.map((feature, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <CheckCircleIcon className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                </div>

                <button
                  className={`w-full rounded-xl py-3 font-bold transition-all ${
                    selectedPlan === plan.id
                      ? "bg-indigo-600 text-white shadow-lg"
                      : "bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700"
                  }`}
                >
                  {selectedPlan === plan.id ? "Selecionado" : "Selecionar"}
                </button>
              </div>
            ))}
        </div>

        {/* Investment Form */}
        {selectedPlan && Array.isArray(plans) && plans.find((p) => p.id === selectedPlan) && (
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-8 animate-fade-in">
            <h3 className="text-2xl font-bold mb-6">Confirme Seu Investimento</h3>

            <div className="max-w-md space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Plano Selecionado
                </label>
                <div className="p-4 rounded-xl bg-indigo-100 dark:bg-indigo-900/30 border border-indigo-300 dark:border-indigo-700">
                  <p className="font-bold text-lg">{plans.find((p) => p.id === selectedPlan)?.nome || "Plano"}</p>
                  <p className="text-sm text-indigo-700 dark:text-indigo-400">
                    {plans.find((p) => p.id === selectedPlan)?.rendimentoDiario || 0}% ao dia
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Valor do Investimento
                </label>
                <input
                  type="number"
                  value={investmentAmount}
                  onChange={(e) => setInvestmentAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                  Mínimo: R$ {plans.find((p) => p.id === selectedPlan)?.valorMinimo?.toLocaleString() || "0"} • Máximo:
                  R$ {plans.find((p) => p.id === selectedPlan)?.valorMaximo?.toLocaleString() || "0"}
                </p>
              </div>

              {investmentAmount && Number(investmentAmount) > 0 && (
                <div className="p-4 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
                  <p className="text-sm font-bold text-green-900 dark:text-green-300 mb-2">Projeção de Retorno</p>
                  <div className="space-y-1 text-sm text-green-800 dark:text-green-400">
                    <p>
                      <strong>Por dia:</strong> R${" "}
                      {(
                        (Number(investmentAmount) * (plans.find((p) => p.id === selectedPlan)?.rendimentoDiario || 0)) /
                        100
                      ).toFixed(2)}
                    </p>
                    <p>
                      <strong>Em 30 dias:</strong> R${" "}
                      {(
                        (Number(investmentAmount) * (plans.find((p) => p.id === selectedPlan)?.retornoTotal || 0)) /
                        100
                      ).toFixed(2)}
                    </p>
                    <p>
                      <strong>Total após 30 dias:</strong> R${" "}
                      {(
                        Number(investmentAmount) +
                        (Number(investmentAmount) * (plans.find((p) => p.id === selectedPlan)?.retornoTotal || 0)) / 100
                      ).toFixed(2)}
                    </p>
                  </div>
                </div>
              )}

              <button
                onClick={handleInvest}
                disabled={!investmentAmount || Number(investmentAmount) <= 0}
                className="w-full rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 py-4 text-white text-lg font-bold shadow-2xl shadow-indigo-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Confirmar Investimento
              </button>
            </div>
          </div>
        )}

        {/* Info Section */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-8">
          <h3 className="text-2xl font-bold mb-6">Por que investir conosco?</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="h-12 w-12 rounded-xl bg-green-100 dark:bg-green-900/30 grid place-items-center mb-3">
                <CheckCircleIcon className="h-7 w-7 text-green-600 dark:text-green-400" />
              </div>
              <h4 className="font-bold text-lg">Segurança Garantida</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Plataforma 100% segura com criptografia de ponta a ponta. Seus investimentos protegidos 24/7.
              </p>
            </div>
            <div className="space-y-2">
              <div className="h-12 w-12 rounded-xl bg-purple-100 dark:bg-purple-900/30 grid place-items-center mb-3">
                <BoltIcon className="h-7 w-7 text-purple-600 dark:text-purple-400" />
              </div>
              <h4 className="font-bold text-lg">Rendimento Automático</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Seus lucros são calculados e creditados automaticamente todos os dias. Sem complicação.
              </p>
            </div>
            <div className="space-y-2">
              <div className="h-12 w-12 rounded-xl bg-blue-100 dark:bg-blue-900/30 grid place-items-center mb-3">
                <StarIcon className="h-7 w-7 text-blue-600 dark:text-blue-400" />
              </div>
              <h4 className="font-bold text-lg">Suporte Premium</h4>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Equipe especializada pronta para ajudar. Tire suas dúvidas a qualquer momento.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
