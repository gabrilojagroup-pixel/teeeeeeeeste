"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  ChartBarIcon,
  ArrowDownIcon,
  ArrowUpIcon,
  SparklesIcon,
  ArrowLeftIcon,
  UserGroupIcon,
  CalendarIcon,
} from "@heroicons/react/24/solid"

type Transaction = {
  id: number
  type: "deposit" | "withdrawal" | "referral_level1" | "referral_level2" | "referral_level3" | "checkin"
  amount: number
  date: string
  description: string
  status: "completed" | "pending" | "processing"
}

export default function InvestimentosPage() {
  const router = useRouter()
  const [filter, setFilter] = useState<"all" | "deposit" | "withdrawal" | "referral" | "checkin">("all")

  const transactions: Transaction[] = [
    {
      id: 1,
      type: "deposit",
      amount: 500.0,
      date: "2025-01-02 14:30",
      description: "Depósito via PIX",
      status: "completed",
    },
    {
      id: 2,
      type: "referral_level1",
      amount: 75.0,
      date: "2025-01-02 12:15",
      description: "Comissão Nível 1 - João Silva",
      status: "completed",
    },
    {
      id: 3,
      type: "checkin",
      amount: 1.0,
      date: "2025-01-02 08:00",
      description: "Check-in diário",
      status: "completed",
    },
    {
      id: 4,
      type: "withdrawal",
      amount: 200.0,
      date: "2025-01-01 18:45",
      description: "Saque via PIX",
      status: "processing",
    },
    {
      id: 5,
      type: "referral_level2",
      amount: 15.0,
      date: "2025-01-01 16:20",
      description: "Comissão Nível 2 - Pedro Costa",
      status: "completed",
    },
    {
      id: 6,
      type: "deposit",
      amount: 1000.0,
      date: "2025-01-01 10:00",
      description: "Depósito via PIX",
      status: "completed",
    },
    {
      id: 7,
      type: "checkin",
      amount: 1.0,
      date: "2025-01-01 08:00",
      description: "Check-in diário",
      status: "completed",
    },
    {
      id: 8,
      type: "referral_level1",
      amount: 150.0,
      date: "2024-12-31 14:30",
      description: "Comissão Nível 1 - Maria Santos",
      status: "completed",
    },
    {
      id: 9,
      type: "referral_level3",
      amount: 10.0,
      date: "2024-12-31 11:15",
      description: "Comissão Nível 3 - Roberto Alves",
      status: "completed",
    },
    {
      id: 10,
      type: "deposit",
      amount: 750.0,
      date: "2024-12-30 16:00",
      description: "Depósito via PIX",
      status: "completed",
    },
  ]

  const filteredTransactions = transactions.filter((t) => {
    if (filter === "all") return true
    if (filter === "referral") return t.type.startsWith("referral_")
    return t.type === filter
  })

  const totals = {
    deposits: transactions
      .filter((t) => t.type === "deposit" && t.status === "completed")
      .reduce((acc, t) => acc + t.amount, 0),
    withdrawals: transactions
      .filter((t) => t.type === "withdrawal" && t.status === "completed")
      .reduce((acc, t) => acc + t.amount, 0),
    referrals: transactions
      .filter((t) => t.type.startsWith("referral_") && t.status === "completed")
      .reduce((acc, t) => acc + t.amount, 0),
    checkins: transactions
      .filter((t) => t.type === "checkin" && t.status === "completed")
      .reduce((acc, t) => acc + t.amount, 0),
  }

  const getTransactionIcon = (type: Transaction["type"]) => {
    if (type === "deposit") return <ArrowDownIcon className="h-5 w-5 text-green-500" />
    if (type === "withdrawal") return <ArrowUpIcon className="h-5 w-5 text-red-500" />
    if (type.startsWith("referral_")) return <UserGroupIcon className="h-5 w-5 text-purple-500" />
    if (type === "checkin") return <CalendarIcon className="h-5 w-5 text-blue-500" />
  }

  const getTransactionColor = (type: Transaction["type"]) => {
    if (type === "deposit") return "text-green-600 dark:text-green-400"
    if (type === "withdrawal") return "text-red-600 dark:text-red-400"
    if (type.startsWith("referral_")) return "text-purple-600 dark:text-purple-400"
    if (type === "checkin") return "text-blue-600 dark:text-blue-400"
  }

  const getStatusBadge = (status: Transaction["status"]) => {
    if (status === "completed")
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400">
          Concluído
        </span>
      )
    if (status === "processing")
      return (
        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400">
          Processando
        </span>
      )
    return (
      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
        Pendente
      </span>
    )
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-slate-900 text-slate-900 dark:text-slate-50 transition-all duration-500">
      {/* Header */}
      <header className="border-b border-slate-200/50 dark:border-slate-800/50 backdrop-blur-xl bg-white/50 dark:bg-slate-900/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.back()}
              className="p-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
            >
              <ArrowLeftIcon className="h-5 w-5" />
            </button>
            <div className="h-11 w-11 grid place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg shadow-indigo-500/50">
              <SparklesIcon className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent">
              Relatório Financeiro
            </span>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Summary Cards */}
        <div className="grid md:grid-cols-4 gap-6">
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <ArrowDownIcon className="h-5 w-5 text-green-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Total Depósitos</span>
            </div>
            <p className="text-3xl font-bold text-green-600 dark:text-green-400">R$ {totals.deposits.toFixed(2)}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Entradas confirmadas</p>
          </div>

          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <ArrowUpIcon className="h-5 w-5 text-red-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Total Saques</span>
            </div>
            <p className="text-3xl font-bold text-red-600 dark:text-red-400">R$ {totals.withdrawals.toFixed(2)}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Saídas processadas</p>
          </div>

          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <UserGroupIcon className="h-5 w-5 text-purple-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Comissões</span>
            </div>
            <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">R$ {totals.referrals.toFixed(2)}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Níveis 1, 2 e 3</p>
          </div>

          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <CalendarIcon className="h-5 w-5 text-blue-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Check-ins</span>
            </div>
            <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">R$ {totals.checkins.toFixed(2)}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Bônus diário</p>
          </div>
        </div>

        {/* Filters */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => setFilter("all")}
              className={`px-5 py-2.5 rounded-xl font-semibold transition-all ${
                filter === "all"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/30"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              Todas ({transactions.length})
            </button>
            <button
              onClick={() => setFilter("deposit")}
              className={`px-5 py-2.5 rounded-xl font-semibold transition-all ${
                filter === "deposit"
                  ? "bg-green-600 text-white shadow-lg shadow-green-500/30"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              Depósitos
            </button>
            <button
              onClick={() => setFilter("withdrawal")}
              className={`px-5 py-2.5 rounded-xl font-semibold transition-all ${
                filter === "withdrawal"
                  ? "bg-red-600 text-white shadow-lg shadow-red-500/30"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              Saques
            </button>
            <button
              onClick={() => setFilter("referral")}
              className={`px-5 py-2.5 rounded-xl font-semibold transition-all ${
                filter === "referral"
                  ? "bg-purple-600 text-white shadow-lg shadow-purple-500/30"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              Comissões
            </button>
            <button
              onClick={() => setFilter("checkin")}
              className={`px-5 py-2.5 rounded-xl font-semibold transition-all ${
                filter === "checkin"
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-500/30"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              Check-ins
            </button>
          </div>
        </div>

        {/* Transactions Table */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
          <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
            <ChartBarIcon className="h-6 w-6 text-indigo-500" />
            Histórico de Transações
          </h3>

          <div className="space-y-3">
            {filteredTransactions.map((transaction) => (
              <div
                key={transaction.id}
                className="flex items-center justify-between p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-700 transition-all"
              >
                <div className="flex items-center gap-4 flex-1">
                  <div className="h-12 w-12 rounded-xl bg-white dark:bg-slate-800 grid place-items-center shadow-sm">
                    {getTransactionIcon(transaction.type)}
                  </div>

                  <div className="flex-1">
                    <p className="font-bold text-lg mb-0.5">{transaction.description}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                      {new Date(transaction.date).toLocaleString("pt-BR")}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  {getStatusBadge(transaction.status)}

                  <p className={`text-2xl font-bold ${getTransactionColor(transaction.type)} min-w-[140px] text-right`}>
                    {transaction.type === "withdrawal" ? "-" : "+"}R$ {transaction.amount.toFixed(2)}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {filteredTransactions.length === 0 && (
            <div className="text-center py-12">
              <p className="text-slate-500 dark:text-slate-400">Nenhuma transação encontrada neste filtro.</p>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
