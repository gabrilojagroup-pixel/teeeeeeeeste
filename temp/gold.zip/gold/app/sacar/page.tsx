"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, CheckCircle2, Wallet } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { validateCPF, validateCNPJ, formatCPF, formatCNPJ, cleanDocument } from "@/lib/utils"
import { getGlobalConfig, getDefaultConfig } from "@/lib/global-config"

type User = {
  id: number
  nome: string
  email: string
  saldo: number
  chavePix?: string
  cpf?: string
}

export default function SacarPage() {
  const router = useRouter()
  const [usuario, setUsuario] = useState<User | null>(null)
  const [valor, setValor] = useState("")
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [chavePix, setChavePix] = useState("")
  const [tipoChave, setTipoChave] = useState<"cpf" | "cnpj" | "email" | "phone" | "random">("cpf")
  const [documento, setDocumento] = useState("")
  const [nomeCompleto, setNomeCompleto] = useState("")

  const [config, setConfig] = useState(() => {
    const defaultConfig = getDefaultConfig()
    if (typeof window !== "undefined") {
      return getGlobalConfig() || defaultConfig
    }
    return defaultConfig
  })

  useEffect(() => {
    setConfig(getGlobalConfig() || getDefaultConfig())

    const handleConfigUpdate = () => {
      setConfig(getGlobalConfig() || getDefaultConfig())
    }

    window.addEventListener("globalConfigUpdated", handleConfigUpdate)
    return () => window.removeEventListener("globalConfigUpdated", handleConfigUpdate)
  }, [])

  const withdrawalFee = config?.taxas?.saque ?? 15
  const minWithdrawal = config?.limites?.saqueMinimo ?? 30

  useEffect(() => {
    const usuarioLogado = localStorage.getItem("usuarioLogado")
    if (!usuarioLogado) {
      router.push("/login")
      return
    }
    const user = JSON.parse(usuarioLogado)
    setUsuario(user)
    setNomeCompleto(user.nome || "")
    if (user.cpf) setDocumento(user.cpf)
    if (user.chavePix) {
      setChavePix(user.chavePix)
      if (user.chavePix.includes("@")) setTipoChave("email")
      else if (user.chavePix.match(/^\d{11}$/)) setTipoChave("cpf")
      else if (user.chavePix.match(/^\d{14}$/)) setTipoChave("cnpj")
      else if (user.chavePix.match(/^\d{2}/)) setTipoChave("phone")
      else setTipoChave("random")
    }
  }, [router])

  const handleWithdraw = async () => {
    if (!usuario) return

    const requestedAmount = Number(valor)
    if (!requestedAmount || requestedAmount < minWithdrawal) {
      alert(`⚠️ Valor mínimo de saque é R$ ${minWithdrawal.toFixed(2)}`)
      return
    }

    const feeAmount = (requestedAmount * withdrawalFee) / 100
    const netAmount = requestedAmount - feeAmount

    if (requestedAmount > usuario.saldo) {
      alert("⚠️ Saldo insuficiente")
      return
    }

    if (!chavePix || !documento || !nomeCompleto) {
      alert("⚠️ Preencha todos os campos obrigatórios")
      return
    }

    if (tipoChave === "cpf" && !validateCPF(documento)) {
      alert("⚠️ CPF inválido! Verifique o número digitado.")
      return
    }

    if (tipoChave === "cnpj" && !validateCNPJ(documento)) {
      alert("⚠️ CNPJ inválido! Verifique o número digitado.")
      return
    }

    const cleanedDoc = cleanDocument(documento)
    let cleanedPixKey = chavePix

    if (tipoChave === "cpf" || tipoChave === "cnpj" || tipoChave === "phone") {
      cleanedPixKey = cleanDocument(chavePix)
    }

    if (
      !confirm(
        `💸 Confirmação de Saque:\n\nValor solicitado: R$ ${requestedAmount.toFixed(2)}\nTaxa (${withdrawalFee}%): R$ ${feeAmount.toFixed(2)}\nValor líquido a receber: R$ ${netAmount.toFixed(2)}\n\nDeseja continuar?`,
      )
    ) {
      return
    }

    setLoading(true)

    try {
      const response = await fetch("/api/pix/withdraw", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: netAmount, // Send net amount to API
          pixKey: cleanedPixKey,
          pixKeyType: tipoChave,
          receiverName: nomeCompleto,
          receiverDocument: cleanedDoc,
          userId: usuario.id,
        }),
      })

      const responseText = await response.text()
      let result

      try {
        result = JSON.parse(responseText)
      } catch (e) {
        throw new Error("Resposta inválida da API: " + responseText)
      }

      if (result.success) {
        const usuarioAtualizado = {
          ...usuario,
          saldo: usuario.saldo - requestedAmount,
        }

        localStorage.setItem("usuarioLogado", JSON.stringify(usuarioAtualizado))

        const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]")
        const index = usuarios.findIndex((u: any) => u.id === usuario.id)
        if (index !== -1) {
          usuarios[index] = usuarioAtualizado
          localStorage.setItem("usuarios", JSON.stringify(usuarios))
        }

        const transacoes = JSON.parse(localStorage.getItem("transacoes") || "[]")
        transacoes.unshift({
          id: Date.now(),
          tipo: "SAQUE",
          valor: requestedAmount,
          status: "PROCESSANDO",
          data: new Date().toISOString(),
          descricao: `Saque via PIX - Taxa ${withdrawalFee}%: R$ ${feeAmount.toFixed(2)} - Líquido: R$ ${netAmount.toFixed(2)}`,
          identifier: result.identifier,
          userId: usuario.id,
          userName: usuario.nome,
        })
        localStorage.setItem("transacoes", JSON.stringify(transacoes))

        setSuccess(true)
        setTimeout(() => router.push("/dashboard"), 3000)
      } else {
        throw new Error(result.error || "Erro desconhecido")
      }
    } catch (error: any) {
      console.error("[v0] Withdrawal error:", error)
      alert("❌ Erro ao processar saque: " + error.message)
    } finally {
      setLoading(false)
    }
  }

  if (!usuario) return null

  const requestedAmount = Number(valor)
  const feeAmount = (requestedAmount * withdrawalFee) / 100
  const netAmount = requestedAmount - feeAmount

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-slate-900 text-slate-900 dark:text-slate-50 transition-all duration-500">
      <header className="border-b border-slate-200/50 dark:border-slate-800/50 backdrop-blur-xl bg-white/50 dark:bg-slate-900/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button onClick={() => router.back()} variant="outline">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="h-11 w-11 grid place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg shadow-indigo-500/50">
              <Wallet className="h-6 w-6 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent">
              💸 Sacar Fundos
            </CardTitle>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">
        {/* Balance Card */}
        <Card className="rounded-3xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-8 text-white shadow-2xl shadow-indigo-500/30">
          <CardHeader>
            <div className="flex items-center gap-3 mb-4">
              <Wallet className="h-10 w-10" />
              <div>
                <p className="text-sm opacity-80">Saldo Disponível para Saque</p>
                <h1 className="text-5xl font-bold">R$ {usuario.saldo.toFixed(2)}</h1>
              </div>
            </div>
            <CardDescription className="text-white/80 text-lg">
              💰 Saques instantâneos via PIX • Taxa de saque: {withdrawalFee}%
            </CardDescription>
          </CardHeader>
        </Card>

        {success ? (
          <Card className="rounded-3xl border border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20 p-12 text-center animate-fade-in">
            <CheckCircle2 className="h-20 w-20 text-green-600 dark:text-green-400 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-green-900 dark:text-green-300 mb-2">✅ Saque em Análise!</h2>
            <p className="text-lg text-green-700 dark:text-green-400 mb-4">
              Seu saque está sendo processado e será liberado em breve. Aguarde a aprovação do administrador.
            </p>
            <p className="text-sm text-green-600 dark:text-green-500">Redirecionando para o dashboard...</p>
          </Card>
        ) : (
          <Card className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-8">
            <CardHeader>
              <CardTitle className="text-2xl font-bold mb-6">💳 Solicitar Saque via PIX</CardTitle>
            </CardHeader>
            <CardContent>
              {/* Warning about withdrawal fee */}
              <div className="p-5 rounded-xl bg-amber-50 dark:bg-amber-900/20 border-2 border-amber-300 dark:border-amber-700">
                <div className="flex items-start gap-3">
                  <div className="h-6 w-6 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-amber-900 dark:text-amber-300 mb-2">
                      ⚡ Taxa de Saque: {withdrawalFee}%
                    </h4>
                    <p className="text-sm text-amber-800 dark:text-amber-400">
                      Todos os saques estão sujeitos a uma taxa de {withdrawalFee}% sobre o valor solicitado. O valor
                      líquido será creditado em sua chave PIX após a dedução da taxa.
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-xl bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
                <h4 className="font-bold text-blue-900 dark:text-blue-300 mb-4">📋 Dados Obrigatórios</h4>
                <div className="space-y-4">
                  <div>
                    <Label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      Nome Completo *
                    </Label>
                    <Input
                      type="text"
                      value={nomeCompleto}
                      onChange={(e) => setNomeCompleto(e.target.value)}
                      placeholder="Nome completo do recebedor"
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                      disabled={loading}
                    />
                  </div>

                  <div>
                    <Label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      CPF/CNPJ *
                    </Label>
                    <Input
                      type="text"
                      value={documento}
                      onChange={(e) => {
                        const value = e.target.value
                        const cleaned = cleanDocument(value)
                        if (cleaned.length <= 18) {
                          setDocumento(
                            cleaned.length === 11
                              ? formatCPF(cleaned)
                              : cleaned.length === 14
                                ? formatCNPJ(cleaned)
                                : value,
                          )
                        }
                      }}
                      placeholder="000.000.000-00"
                      maxLength={18}
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                      disabled={loading}
                    />
                    {documento && (tipoChave === "cpf" ? validateCPF(documento) : validateCNPJ(documento)) && (
                      <p className="text-sm text-green-600 dark:text-green-400 mt-1">✓ Documento válido</p>
                    )}
                  </div>

                  <div>
                    <Label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      Tipo de Chave PIX *
                    </Label>
                    <Select
                      value={tipoChave}
                      onChange={(e) => {
                        setTipoChave(e.target.value as any)
                        setChavePix("")
                      }}
                      disabled={loading}
                    >
                      <SelectTrigger className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500">
                        <SelectValue placeholder="Selecione o tipo de chave" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cpf">CPF</SelectItem>
                        <SelectItem value="cnpj">CNPJ</SelectItem>
                        <SelectItem value="email">E-mail</SelectItem>
                        <SelectItem value="phone">Telefone</SelectItem>
                        <SelectItem value="random">Chave Aleatória</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      Chave PIX *
                    </Label>
                    <Input
                      type="text"
                      value={chavePix}
                      onChange={(e) => {
                        const value = e.target.value
                        if (tipoChave === "cpf") {
                          const cleaned = cleanDocument(value)
                          if (cleaned.length <= 11) {
                            setChavePix(cleaned.length === 11 ? formatCPF(cleaned) : value)
                          }
                        } else if (tipoChave === "phone") {
                          const cleaned = cleanDocument(value)
                          if (cleaned.length <= 11) {
                            setChavePix(cleaned.length >= 10 ? formatCPF(cleaned) : value)
                          }
                        } else {
                          setChavePix(value)
                        }
                      }}
                      placeholder={
                        tipoChave === "cpf"
                          ? "000.000.000-00"
                          : tipoChave === "email"
                            ? "email@exemplo.com"
                            : tipoChave === "phone"
                              ? "(00) 00000-0000"
                              : "Chave PIX"
                      }
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                      disabled={loading}
                    />
                  </div>
                </div>
              </div>

              <div>
                <Label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Valor do Saque (mínimo R$ {minWithdrawal.toFixed(2)}) *
                </Label>
                <Input
                  type="number"
                  value={valor}
                  onChange={(e) => setValor(e.target.value)}
                  placeholder="0.00"
                  max={usuario.saldo}
                  min={minWithdrawal}
                  step="0.01"
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-6 py-4 text-2xl font-bold focus:outline-none focus:ring-2 focus:ring-purple-500"
                  disabled={loading}
                />
                <div className="flex justify-between mt-2">
                  <Button
                    onClick={() => setValor(String((usuario.saldo / 2).toFixed(2)))}
                    variant="outline"
                    className="text-sm text-indigo-600 dark:text-indigo-400 hover:underline font-semibold"
                  >
                    50% do saldo
                  </Button>
                  <Button
                    onClick={() => setValor(String(usuario.saldo.toFixed(2)))}
                    variant="outline"
                    className="text-sm text-indigo-600 dark:text-indigo-400 hover:underline font-semibold"
                  >
                    Sacar tudo
                  </Button>
                </div>
              </div>

              {chavePix && documento && nomeCompleto && valor && requestedAmount >= minWithdrawal && (
                <div className="p-6 rounded-xl bg-purple-50 dark:bg-purple-900/20 border-2 border-purple-300 dark:border-purple-700">
                  <h4 className="font-bold text-purple-900 dark:text-purple-300 mb-3 text-lg">📊 Resumo do Saque:</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center pb-2 border-b border-purple-200 dark:border-purple-800">
                      <span className="text-purple-700 dark:text-purple-400">Valor solicitado:</span>
                      <span className="font-bold text-lg text-purple-900 dark:text-purple-300">
                        R$ {requestedAmount.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center pb-2 border-b border-purple-200 dark:border-purple-800">
                      <span className="text-purple-700 dark:text-purple-400">Taxa de saque ({withdrawalFee}%):</span>
                      <span className="font-bold text-lg text-red-600 dark:text-red-400">
                        - R$ {feeAmount.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center pt-2">
                      <span className="text-purple-700 dark:text-purple-400 font-semibold">Você receberá via PIX:</span>
                      <span className="text-3xl font-bold text-green-600 dark:text-green-400">
                        R$ {netAmount.toFixed(2)}
                      </span>
                    </div>
                    <div className="mt-4 pt-4 border-t border-purple-200 dark:border-purple-800 space-y-1 text-sm">
                      <p className="text-purple-700 dark:text-purple-400">
                        <strong>Nome:</strong> {nomeCompleto}
                      </p>
                      <p className="text-purple-700 dark:text-purple-400">
                        <strong>Documento:</strong> {documento}
                      </p>
                      <p className="text-purple-700 dark:text-purple-400">
                        <strong>Chave PIX ({tipoChave}):</strong> {chavePix}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <Button
                onClick={handleWithdraw}
                disabled={
                  loading ||
                  !valor ||
                  requestedAmount < minWithdrawal ||
                  requestedAmount > usuario.saldo ||
                  !chavePix ||
                  !documento ||
                  !(tipoChave === "cpf" ? validateCPF(documento) : validateCNPJ(documento)) ||
                  !nomeCompleto
                }
                className="w-full rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 py-5 text-white text-lg font-bold shadow-2xl shadow-purple-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
              >
                {loading ? (
                  <>
                    <div className="h-6 w-6 border-4 border-white/30 border-t-white rounded-full animate-spin" />
                    Processando Saque...
                  </>
                ) : (
                  <>
                    <Wallet className="h-6 w-6" />
                    Confirmar Saque de R$ {netAmount.toFixed(2)}
                  </>
                )}
              </Button>

              <div className="p-4 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
                <p className="text-sm text-green-900 dark:text-green-300">
                  <strong>✅ Saque Seguro:</strong> Seu saque será analisado pelo administrador antes de ser liberado.
                  Após aprovação, o valor será transferido automaticamente para sua chave PIX via PoseidonPay.
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </main>
  )
}
