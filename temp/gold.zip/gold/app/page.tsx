"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import {
  SunIcon,
  MoonIcon,
  ClipboardIcon,
  CheckIcon,
  ArrowTrendingUpIcon,
  UserGroupIcon,
  WalletIcon,
  BanknotesIcon,
  ChartBarIcon,
  TrophyIcon,
  BellIcon,
  ArrowUpIcon,
  SparklesIcon,
} from "@heroicons/react/24/solid"

type Notification = {
  id: number
  text: string
  time: string
}

type User = {
  name: string
  value: number
  nivel: number
}

export default function Home() {
  const router = useRouter()
  const [saldo, setSaldo] = useState(2547.82)
  const [rend24h, setRend24h] = useState(50.96)
  const [bonusRef, setBonusRef] = useState(340.5)
  const [deposito, setDeposito] = useState("")
  const [saque, setSaque] = useState("")
  const [copiado, setCopiado] = useState(false)
  const [tema, setTema] = useState<"dark" | "light">("dark")
  const [usersOnline, setUsersOnline] = useState(2847)
  const [indicados, setIndicados] = useState(12)
  const [nivel, setNivel] = useState(2)
  const [notifications, setNotifications] = useState<Notification[]>([
    { id: 1, text: "João P. depositou R$ 500", time: "2min" },
    { id: 2, text: "Você recebeu +R$ 24,50 de rendimento", time: "1h" },
    { id: 3, text: "Maria S. usou seu link", time: "3h" },
  ])

  const refCode = `FUT${Math.random().toString(36).substring(2, 8).toUpperCase()}`
  const refLink = `https://investfutura.com/?ref=${refCode}`

  const ranking: User[] = [
    { name: "Carlos M.", value: 15420.5, nivel: 5 },
    { name: "Ana Paula R.", value: 12890.3, nivel: 4 },
    { name: "Você", value: saldo, nivel },
    { name: "Pedro S.", value: 8234.8, nivel: 3 },
    { name: "Julia F.", value: 6890.2, nivel: 3 },
  ]

  useEffect(() => {
    const usuarioLogado = localStorage.getItem("usuarioLogado")
    if (usuarioLogado) {
      router.push("/dashboard")
    } else {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    const t = setInterval(() => setUsersOnline((n) => n + Math.floor(Math.random() * 5 - 2)), 6000)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    // Simula rendimento diário
    const interval = setInterval(() => {
      const novoRend = saldo * 0.02
      setRend24h(novoRend)
      setSaldo((s) => s + novoRend)

      const newNotif: Notification = {
        id: Date.now(),
        text: `Você recebeu +R$ ${novoRend.toFixed(2)} de rendimento`,
        time: "agora",
      }
      setNotifications((prev) => [newNotif, ...prev.slice(0, 4)])
    }, 86400000)
    return () => clearInterval(interval)
  }, [saldo])

  const handleDeposito = () => {
    const v = Number(deposito)
    if (!v || v < 10) return
    setSaldo((s) => s + v)
    setDeposito("")

    const newNotif: Notification = {
      id: Date.now(),
      text: `Depósito de R$ ${v.toFixed(2)} confirmado`,
      time: "agora",
    }
    setNotifications((prev) => [newNotif, ...prev.slice(0, 4)])
  }

  const handleSaque = () => {
    const v = Number(saque)
    if (!v || v > saldo || v < 50) return
    setSaldo((s) => s - v)
    setSaque("")

    const newNotif: Notification = {
      id: Date.now(),
      text: `Saque de R$ ${v.toFixed(2)} solicitado`,
      time: "agora",
    }
    setNotifications((prev) => [newNotif, ...prev.slice(0, 4)])
  }

  const copyRef = () => {
    navigator.clipboard.writeText(refLink)
    setCopiado(true)
    setTimeout(() => setCopiado(false), 2000)
  }

  return (
    <div className={tema === "dark" ? "dark" : ""}>
      <main className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-slate-900 text-slate-900 dark:text-slate-50 transition-all duration-500">
        {/* Header */}
        <header className="border-b border-slate-200/50 dark:border-slate-800/50 backdrop-blur-xl bg-white/50 dark:bg-slate-900/50 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-11 w-11 grid place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg shadow-indigo-500/50">
                <SparklesIcon className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent">
                InvestFutura
              </span>
            </div>

            <div className="flex items-center gap-4">
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-sm font-medium">
                <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                {usersOnline.toLocaleString()} online
              </div>

              <button
                onClick={() => setTema(tema === "dark" ? "light" : "dark")}
                className="p-2.5 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
              >
                {tema === "dark" ? (
                  <SunIcon className="h-5 w-5 text-amber-500" />
                ) : (
                  <MoonIcon className="h-5 w-5 text-indigo-600" />
                )}
              </button>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
          {/* Hero Stats */}
          <div className="grid md:grid-cols-4 gap-6">
            <div className="md:col-span-1 rounded-3xl bg-gradient-to-br from-indigo-500 to-purple-600 p-6 text-white shadow-2xl shadow-indigo-500/30">
              <div className="flex items-center gap-2 mb-3">
                <WalletIcon className="h-5 w-5 opacity-80" />
                <span className="text-sm font-medium opacity-90">Saldo Total</span>
              </div>
              <p className="text-4xl font-bold mb-2">R$ {saldo.toFixed(2)}</p>
              <p className="text-sm opacity-80">
                Nível {nivel} • {indicados} indicados
              </p>
            </div>

            <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
              <div className="flex items-center gap-2 mb-3">
                <ArrowTrendingUpIcon className="h-5 w-5 text-green-500" />
                <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Rendimento 24h</span>
              </div>
              <p className="text-3xl font-bold text-green-600 dark:text-green-400">+R$ {rend24h.toFixed(2)}</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">+2% ao dia</p>
            </div>

            <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
              <div className="flex items-center gap-2 mb-3">
                <UserGroupIcon className="h-5 w-5 text-purple-500" />
                <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Bônus Afiliados</span>
              </div>
              <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">R$ {bonusRef.toFixed(2)}</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">10% por indicação</p>
            </div>

            <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
              <div className="flex items-center gap-2 mb-3">
                <TrophyIcon className="h-5 w-5 text-amber-500" />
                <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Ranking</span>
              </div>
              <p className="text-3xl font-bold text-amber-600 dark:text-amber-400">#3</p>
              <p className="text-sm text-slate-500 dark:text-slate-400">Top investidores</p>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Coluna Esquerda */}
            <div className="lg:col-span-2 space-y-6">
              {/* Depósito e Saque */}
              <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
                <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
                  <BanknotesIcon className="h-6 w-6 text-indigo-500" />
                  Gerenciar Fundos
                </h3>

                <div className="grid md:grid-cols-2 gap-6">
                  {/* Depósito */}
                  <div className="space-y-3">
                    <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300">
                      Depositar (mín. R$ 10)
                    </label>
                    <input
                      type="number"
                      value={deposito}
                      onChange={(e) => setDeposito(e.target.value)}
                      placeholder="0.00"
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <button
                      onClick={handleDeposito}
                      className="w-full rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 py-3 text-white font-bold shadow-lg shadow-indigo-500/30 transition-all"
                    >
                      Confirmar Depósito
                    </button>
                  </div>

                  {/* Saque */}
                  <div className="space-y-3">
                    <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300">
                      Sacar (mín. R$ 50)
                    </label>
                    <input
                      type="number"
                      value={saque}
                      onChange={(e) => setSaque(e.target.value)}
                      placeholder="0.00"
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                    <button
                      onClick={handleSaque}
                      className="w-full rounded-xl bg-slate-700 hover:bg-slate-800 dark:bg-slate-600 dark:hover:bg-slate-700 py-3 text-white font-bold shadow-lg transition-all"
                    >
                      Solicitar Saque
                    </button>
                  </div>
                </div>

                <div className="mt-6 p-4 rounded-xl bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800">
                  <p className="text-sm font-medium text-indigo-900 dark:text-indigo-300 mb-2">PIX Copia e Cola:</p>
                  <code className="text-xs text-indigo-700 dark:text-indigo-400 break-all select-all">
                    00020126580014br.gov.bcb.pix0136f47ac10b-5c4b-4e8d-8a1f2-3e4f5a6b7c8d52040000530398654071247.825802BR5925InvestFutura
                    LTDA6009SAO PAULO62070503***6304B7C3
                  </code>
                </div>
              </div>

              {/* Link de Afiliado */}
              <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-purple-500/10 to-pink-500/10 dark:from-purple-900/20 dark:to-pink-900/20 backdrop-blur-xl p-6">
                <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
                  <UserGroupIcon className="h-6 w-6 text-purple-500" />
                  Ganhe 10% por Indicação
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                  Compartilhe seu link e receba 10% de todo depósito dos seus indicados instantaneamente.
                </p>

                <div className="flex gap-3">
                  <input
                    readOnly
                    value={refLink}
                    className="flex-1 rounded-xl border border-purple-300 dark:border-purple-700 bg-white dark:bg-slate-800 px-4 py-3 text-sm font-mono select-all"
                  />
                  <button
                    onClick={copyRef}
                    className="px-5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold flex items-center gap-2 transition-all shadow-lg shadow-purple-500/30"
                  >
                    {copiado ? (
                      <>
                        <CheckIcon className="h-5 w-5" />
                        Copiado!
                      </>
                    ) : (
                      <>
                        <ClipboardIcon className="h-5 w-5" />
                        Copiar
                      </>
                    )}
                  </button>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-4">
                  <div className="p-3 rounded-xl bg-white/50 dark:bg-slate-800/50">
                    <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">{indicados}</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">Indicados</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/50 dark:bg-slate-800/50">
                    <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">R$ {bonusRef.toFixed(0)}</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">Ganhos</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/50 dark:bg-slate-800/50">
                    <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">{nivel}</p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">Nível</p>
                  </div>
                </div>
              </div>

              {/* Ranking */}
              <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <ChartBarIcon className="h-6 w-6 text-amber-500" />
                  Top Investidores
                </h3>

                <div className="space-y-3">
                  {ranking.map((user, idx) => (
                    <div
                      key={idx}
                      className={`flex items-center justify-between p-3 rounded-xl ${
                        user.name === "Você"
                          ? "bg-indigo-100 dark:bg-indigo-900/30 border-2 border-indigo-500"
                          : "bg-slate-100 dark:bg-slate-800"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-lg font-bold text-slate-400">#{idx + 1}</span>
                        <div>
                          <p className="font-semibold">{user.name}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">Nível {user.nivel}</p>
                        </div>
                      </div>
                      <p className="font-bold text-indigo-600 dark:text-indigo-400">R$ {user.value.toFixed(2)}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Coluna Direita - Notificações */}
            <div className="space-y-6">
              <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <BellIcon className="h-6 w-6 text-indigo-500" />
                  Atividade Recente
                </h3>

                <div className="space-y-3">
                  {notifications.map((notif) => (
                    <div
                      key={notif.id}
                      className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
                    >
                      <p className="text-sm font-medium mb-1">{notif.text}</p>
                      <p className="text-xs text-slate-500">{notif.time}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Níveis de Indicação */}
              <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-amber-500/10 to-orange-500/10 dark:from-amber-900/20 dark:to-orange-900/20 backdrop-blur-xl p-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <TrophyIcon className="h-6 w-6 text-amber-500" />
                  Níveis VIP
                </h3>

                <div className="space-y-3">
                  {[
                    { nivel: 1, nome: "Bronze", indicados: "0-5", bonus: "10%" },
                    { nivel: 2, nome: "Prata", indicados: "6-15", bonus: "12%" },
                    { nivel: 3, nome: "Ouro", indicados: "16-30", bonus: "15%" },
                    { nivel: 4, nome: "Platina", indicados: "31-50", bonus: "18%" },
                    { nivel: 5, nome: "Diamante", indicados: "51+", bonus: "20%" },
                  ].map((n) => (
                    <div
                      key={n.nivel}
                      className={`p-3 rounded-xl ${
                        nivel === n.nivel
                          ? "bg-amber-100 dark:bg-amber-900/30 border-2 border-amber-500"
                          : "bg-white/50 dark:bg-slate-800/50"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-bold">{n.nome}</p>
                          <p className="text-xs text-slate-500">{n.indicados} indicados</p>
                        </div>
                        <span className="text-lg font-bold text-amber-600 dark:text-amber-400">{n.bonus}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* CTA Sticky Bottom */}
          <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-6 lg:hidden">
            <button
              onClick={copyRef}
              className="rounded-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 px-8 py-4 text-white font-bold shadow-2xl shadow-purple-500/50 flex items-center gap-2 transition-all animate-pulse"
            >
              <ArrowUpIcon className="h-5 w-5" />
              Indicar Amigos
            </button>
          </div>
        </div>
      </main>
    </div>
  )
}
