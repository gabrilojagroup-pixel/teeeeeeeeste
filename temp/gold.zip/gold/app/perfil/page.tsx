"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  UserCircleIcon,
  SparklesIcon,
  ArrowLeftIcon,
  EnvelopeIcon,
  PhoneIcon,
  KeyIcon,
  CheckCircleIcon,
  BanknotesIcon,
} from "@heroicons/react/24/solid"

export default function PerfilPage() {
  const router = useRouter()
  const [profileData, setProfileData] = useState({
    name: "João Silva",
    email: "joao.silva@email.com",
    phone: "(11) 98765-4321",
    cpf: "123.456.789-00",
    pixKey: "",
    pixKeyType: "cpf",
  })

  const [isEditing, setIsEditing] = useState(false)
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    // Save to localStorage
    localStorage.setItem("profileData", JSON.stringify(profileData))
    setSaved(true)
    setIsEditing(false)
    setTimeout(() => setSaved(false), 3000)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-slate-900 text-slate-900 dark:text-slate-50 transition-all duration-500">
      {/* Header */}
      <header className="border-b border-slate-200/50 dark:border-slate-800/50 backdrop-blur-xl bg-white/50 dark:bg-slate-900/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.back()}
              className="p-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
            >
              <ArrowLeftIcon className="h-5 w-5" />
            </button>
            <div className="h-11 w-11 grid place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg shadow-indigo-500/50">
              <SparklesIcon className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent">
              Meu Perfil
            </span>
          </div>

          {saved && (
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 font-semibold">
              <CheckCircleIcon className="h-5 w-5" />
              Salvo com sucesso!
            </div>
          )}
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-6 py-8 space-y-8">
        {/* Profile Header */}
        <div className="rounded-3xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-8 text-white shadow-2xl shadow-indigo-500/30">
          <div className="flex items-center gap-6">
            <div className="h-24 w-24 rounded-full bg-white/20 backdrop-blur-xl grid place-items-center border-4 border-white/30">
              <UserCircleIcon className="h-16 w-16 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold mb-2">{profileData.name}</h1>
              <p className="text-white/90">{profileData.email}</p>
              <p className="text-sm text-white/70 mt-1">Membro desde Janeiro 2025</p>
            </div>
          </div>
        </div>

        {/* Personal Information */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold flex items-center gap-2">
              <UserCircleIcon className="h-6 w-6 text-indigo-500" />
              Informações Pessoais
            </h3>
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold transition-all shadow-lg shadow-indigo-500/30"
            >
              {isEditing ? "Cancelar" : "Editar"}
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-2">
                <UserCircleIcon className="h-4 w-4" />
                Nome Completo
              </label>
              <input
                type="text"
                value={profileData.name}
                onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                disabled={!isEditing}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 font-semibold disabled:opacity-60 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-2">
                <EnvelopeIcon className="h-4 w-4" />
                E-mail
              </label>
              <input
                type="email"
                value={profileData.email}
                onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                disabled={!isEditing}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 font-semibold disabled:opacity-60 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-2">
                  <PhoneIcon className="h-4 w-4" />
                  Telefone
                </label>
                <input
                  type="tel"
                  value={profileData.phone}
                  onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                  disabled={!isEditing}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 font-semibold disabled:opacity-60 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-2">
                  <KeyIcon className="h-4 w-4" />
                  CPF
                </label>
                <input
                  type="text"
                  value={profileData.cpf}
                  disabled
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 px-4 py-3 font-semibold opacity-60 cursor-not-allowed"
                />
              </div>
            </div>
          </div>
        </div>

        {/* PIX Information */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
            <BanknotesIcon className="h-6 w-6 text-green-500" />
            Chave PIX para Saque
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Tipo de Chave
              </label>
              <select
                value={profileData.pixKeyType}
                onChange={(e) => setProfileData({ ...profileData, pixKeyType: e.target.value })}
                disabled={!isEditing}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 font-semibold disabled:opacity-60 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="cpf">CPF</option>
                <option value="email">E-mail</option>
                <option value="phone">Telefone</option>
                <option value="random">Chave Aleatória</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">Chave PIX</label>
              <input
                type="text"
                value={profileData.pixKey}
                onChange={(e) => setProfileData({ ...profileData, pixKey: e.target.value })}
                disabled={!isEditing}
                placeholder="Digite sua chave PIX"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 py-3 font-semibold disabled:opacity-60 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>

            <div className="p-4 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
              <p className="text-sm font-bold text-green-900 dark:text-green-300 mb-2">🔒 Segurança</p>
              <p className="text-sm text-green-800 dark:text-green-400">
                Sua chave PIX é usada exclusivamente para processar seus saques. Ela é armazenada de forma segura e
                criptografada. Os saques são processados em até 24 horas após a solicitação.
              </p>
            </div>
          </div>
        </div>

        {/* Security */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
            <KeyIcon className="h-6 w-6 text-amber-500" />
            Segurança
          </h3>

          <div className="space-y-3">
            <button className="w-full text-left px-5 py-4 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all border border-slate-200 dark:border-slate-700">
              <p className="font-semibold mb-1">Alterar Senha</p>
              <p className="text-sm text-slate-600 dark:text-slate-400">Última alteração há 30 dias</p>
            </button>

            <button className="w-full text-left px-5 py-4 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all border border-slate-200 dark:border-slate-700">
              <p className="font-semibold mb-1">Autenticação de Dois Fatores</p>
              <p className="text-sm text-slate-600 dark:text-slate-400">Adicione uma camada extra de segurança</p>
            </button>
          </div>
        </div>

        {/* Save Button */}
        {isEditing && (
          <button
            onClick={handleSave}
            className="w-full rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 py-4 text-white text-lg font-bold shadow-2xl shadow-indigo-500/30 transition-all flex items-center justify-center gap-2"
          >
            <CheckCircleIcon className="h-6 w-6" />
            Salvar Alterações
          </button>
        )}
      </div>
    </main>
  )
}
