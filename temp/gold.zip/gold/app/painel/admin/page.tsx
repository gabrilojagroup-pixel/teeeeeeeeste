"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  ShieldCheckIcon,
  LockClosedIcon,
  UserGroupIcon,
  BanknotesIcon,
  Cog6ToothIcon,
  ChartBarIcon,
  CheckCircleIcon,
  XCircleIcon,
  PencilIcon,
  TrashIcon,
  KeyIcon,
  ArrowRightOnRectangleIcon,
} from "@heroicons/react/24/solid"
import { getGlobalConfig, saveGlobalConfig, type GlobalConfig } from "@/lib/global-config"

type User = {
  id: number
  nome: string
  email: string
  telefone: string
  cpf?: string
  saldo: number
  rendimento: number
  bonusRef: number
  indicados: number
  nivel: number
  dataCriacao: string
  sponsor?: string
}

type Transaction = {
  id: number
  tipo: string
  valor: number
  status: string
  data: string
  descricao: string
  identifier?: string
  userId?: number
  userName?: string
}

export default function AdminPanel() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loginEmail, setLoginEmail] = useState("")
  const [loginPassword, setLoginPassword] = useState("")
  const [activeTab, setActiveTab] = useState("dashboard")

  const ADMIN_EMAIL = "admin@investfutura.com"
  const ADMIN_PASSWORD = "Admin@2025Secure!"

  const [config, setConfig] = useState<GlobalConfig>(getGlobalConfig())
  const [usuarios, setUsuarios] = useState<User[]>([])
  const [transacoes, setTransacoes] = useState<Transaction[]>([])
  const [editingPlan, setEditingPlan] = useState<GlobalConfig["planos"][0] | null>(null)

  const [selectedUserForBalance, setSelectedUserForBalance] = useState<any>(null)
  const [balanceAdjustment, setBalanceAdjustment] = useState("")
  const [adjustmentReason, setAdjustmentReason] = useState("")

  const [sponsorships, setSponsorships] = useState<any[]>([])
  const [newSponsor, setNewSponsor] = useState({ name: "", logo: "", url: "", value: "" })

  useEffect(() => {
    const adminAuth = localStorage.getItem("adminAuthenticated")
    if (adminAuth === "true") {
      setIsAuthenticated(true)
      loadData()
    }
  }, [])

  useEffect(() => {
    if (isAuthenticated) {
      const interval = setInterval(loadData, 5000)
      return () => clearInterval(interval)
    }
  }, [isAuthenticated])

  // Load sponsorships on initial load
  useEffect(() => {
    const loadedSponsors = JSON.parse(localStorage.getItem("sponsorships") || "[]")
    setSponsorships(loadedSponsors)
  }, [])

  const loadData = () => {
    const users = JSON.parse(localStorage.getItem("usuarios") || "[]")
    const trans = JSON.parse(localStorage.getItem("transacoes") || "[]")
    const globalConfig = getGlobalConfig()

    setUsuarios(users)
    setTransacoes(trans)
    setConfig(globalConfig)
  }

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (loginEmail === ADMIN_EMAIL && loginPassword === ADMIN_PASSWORD) {
      setIsAuthenticated(true)
      localStorage.setItem("adminAuthenticated", "true")
      loadData()
    } else {
      alert("Credenciais inválidas!")
    }
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    localStorage.removeItem("adminAuthenticated")
    router.push("/")
  }

  // Force multiple sync events and reload on save
  const saveConfigChanges = () => {
    saveGlobalConfig(config)
    alert("✅ Configurações salvas! Todas as mudanças foram aplicadas ao site.")
    window.dispatchEvent(new Event("storage"))
    window.dispatchEvent(new StorageEvent("storage", { key: "globalConfig" }))
    setTimeout(() => {
      window.location.reload()
    }, 1000)
  }

  const approveSaque = (transactionId: number) => {
    if (!confirm("Confirmar aprovação deste saque? O valor será transferido via PIX.")) return

    const trans = [...transacoes]
    const index = trans.findIndex((t) => t.id === transactionId)
    if (index !== -1) {
      trans[index].status = "APROVADO"
      setTransacoes(trans)
      localStorage.setItem("transacoes", JSON.stringify(trans))

      // Update user's logged session if online
      if (trans[index].userId) {
        const usuarioLogado = localStorage.getItem("usuarioLogado")
        if (usuarioLogado) {
          const user = JSON.parse(usuarioLogado)
          if (user.id === trans[index].userId) {
            localStorage.setItem("usuarioLogado", JSON.stringify(user))
          }
        }
      }

      alert("✅ Saque aprovado! O valor será transferido via PoseidonPay.")
    }
  }

  const rejectSaque = (transactionId: number) => {
    if (!confirm("Rejeitar este saque? O saldo será devolvido ao usuário.")) return

    const trans = [...transacoes]
    const index = trans.findIndex((t) => t.id === transactionId)
    if (index !== -1) {
      trans[index].status = "REJEITADO"

      if (trans[index].userId) {
        const users = [...usuarios]
        const userIndex = users.findIndex((u) => u.id === trans[index].userId)
        if (userIndex !== -1) {
          users[userIndex].saldo += trans[index].valor
          setUsuarios(users)
          localStorage.setItem("usuarios", JSON.stringify(users))

          const usuarioLogado = localStorage.getItem("usuarioLogado")
          if (usuarioLogado) {
            const user = JSON.parse(usuarioLogado)
            if (user.id === trans[index].userId) {
              user.saldo += trans[index].valor
              localStorage.setItem("usuarioLogado", JSON.stringify(user))
            }
          }
        }
      }

      setTransacoes(trans)
      localStorage.setItem("transacoes", JSON.stringify(trans))
      alert("❌ Saque rejeitado e saldo devolvido ao usuário!")
    }
  }

  const savePlano = () => {
    if (!editingPlan) return

    const updatedPlanos = [...config.planos]
    const index = updatedPlanos.findIndex((p) => p.id === editingPlan.id)

    if (index !== -1) {
      updatedPlanos[index] = editingPlan
    } else {
      editingPlan.id = Date.now()
      updatedPlanos.push(editingPlan)
    }

    const newConfig = { ...config, planos: updatedPlanos }
    setConfig(newConfig)
    saveGlobalConfig(newConfig)
    setEditingPlan(null)
    alert("✅ Plano salvo! Mudanças aplicadas no site.")
  }

  const deletePlano = (id: number) => {
    if (confirm("Deseja realmente excluir este plano?")) {
      const updatedPlanos = config.planos.filter((p) => p.id !== id)
      const newConfig = { ...config, planos: updatedPlanos }
      setConfig(newConfig)
      saveGlobalConfig(newConfig)
      alert("✅ Plano excluído!")
    }
  }

  const togglePlanoAtivo = (id: number) => {
    const updatedPlanos = config.planos.map((p) => (p.id === id ? { ...p, ativo: !p.ativo } : p))
    const newConfig = { ...config, planos: updatedPlanos }
    setConfig(newConfig)
    saveGlobalConfig(newConfig)
  }

  const deleteUser = (userId: number) => {
    if (!confirm("⚠️ ATENÇÃO: Deletar esta conta permanentemente? Esta ação não pode ser desfeita!")) return

    const updatedUsers = usuarios.filter((u) => u.id !== userId)
    setUsuarios(updatedUsers)
    localStorage.setItem("usuarios", JSON.stringify(updatedUsers))

    // Remove from logged session if it's the current user
    const usuarioLogado = localStorage.getItem("usuarioLogado")
    if (usuarioLogado) {
      const user = JSON.parse(usuarioLogado)
      if (user.id === userId) {
        localStorage.removeItem("usuarioLogado")
      }
    }

    alert("✅ Conta deletada permanentemente!")
  }

  const handleBalanceAdjustment = () => {
    if (!selectedUserForBalance || !balanceAdjustment || !adjustmentReason) {
      alert("Preencha todos os campos")
      return
    }

    const adjustment = Number(balanceAdjustment)
    const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]")
    const userIndex = usuarios.findIndex((u: any) => u.id === selectedUserForBalance.id)

    if (userIndex === -1) {
      alert("Usuário não encontrado")
      return
    }

    usuarios[userIndex].saldo += adjustment
    localStorage.setItem("usuarios", JSON.stringify(usuarios))

    const transacoes = JSON.parse(localStorage.getItem("transacoes") || "[]")
    transacoes.unshift({
      id: Date.now(),
      tipo: adjustment > 0 ? "AJUSTE_CREDITO" : "AJUSTE_DEBITO",
      valor: Math.abs(adjustment),
      status: "APROVADO",
      data: new Date().toISOString(),
      descricao: `Ajuste manual pelo admin: ${adjustmentReason}`,
      userId: selectedUserForBalance.id,
      userName: selectedUserForBalance.nome,
    })
    localStorage.setItem("transacoes", JSON.stringify(transacoes))

    alert(`Saldo ajustado com sucesso! ${adjustment > 0 ? "+" : ""}R$ ${adjustment.toFixed(2)}`)
    setSelectedUserForBalance(null)
    setBalanceAdjustment("")
    setAdjustmentReason("")
    loadData()
  }

  // Add sponsorship management functions
  const handleAddSponsorship = () => {
    if (!newSponsor.name || !newSponsor.value) {
      alert("Preencha os campos obrigatórios")
      return
    }

    const sponsor = {
      id: Date.now(),
      ...newSponsor,
      createdAt: new Date().toISOString(),
    }

    const updated = [...sponsorships, sponsor]
    setSponsorships(updated)
    localStorage.setItem("sponsorships", JSON.stringify(updated))
    setNewSponsor({ name: "", logo: "", url: "", value: "" })
    alert("✅ Patrocínio adicionado!")
  }

  const handleDeleteSponsorship = (id: number) => {
    if (confirm("Deletar este patrocínio?")) {
      const updated = sponsorships.filter((s) => s.id !== id)
      setSponsorships(updated)
      localStorage.setItem("sponsorships", JSON.stringify(updated))
    }
  }

  // Estatísticas
  const totalDepositos = transacoes
    .filter((t) => t.tipo === "DEPOSITO" && t.status === "APROVADO")
    .reduce((acc, t) => acc + t.valor, 0)

  const totalSaques = transacoes
    .filter((t) => t.tipo === "SAQUE" && t.status === "APROVADO")
    .reduce((acc, t) => acc + t.valor, 0)

  const saldoTotal = usuarios.reduce((acc, u) => acc + u.saldo, 0)
  const rendimentoTotal = usuarios.reduce((acc, u) => acc + u.rendimento, 0)
  const saquesPendentes = transacoes.filter((t) => t.tipo === "SAQUE" && t.status === "PROCESSANDO")
  const pacotesAtivos = usuarios.filter((u) => u.rendimento > 0).length

  if (!isAuthenticated) {
    return (
      <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="rounded-3xl border border-slate-700 bg-slate-800/50 backdrop-blur-xl p-8 shadow-2xl">
            <div className="flex justify-center mb-6">
              <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <ShieldCheckIcon className="h-10 w-10 text-white" />
              </div>
            </div>

            <h1 className="text-3xl font-bold text-center text-white mb-2">Painel Administrativo</h1>
            <p className="text-center text-slate-400 mb-8">Acesso restrito - Somente administradores</p>

            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">E-mail</label>
                <input
                  type="email"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  placeholder="admin@investfutura.com"
                  className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Senha</label>
                <input
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 py-3 text-white font-bold shadow-lg shadow-purple-500/30 transition-all flex items-center justify-center gap-2"
              >
                <LockClosedIcon className="h-5 w-5" />
                Entrar no Painel
              </button>
            </form>

            <div className="mt-6 p-4 rounded-xl bg-amber-900/20 border border-amber-700">
              <p className="text-xs text-amber-300 text-center">🔒 Área protegida - Todas as ações são registradas</p>
            </div>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-800/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <ShieldCheckIcon className="h-6 w-6 text-white" />
            </div>
            <div>
              <span className="text-xl font-bold">Painel Administrativo</span>
              <p className="text-xs text-slate-400">Controle Total do Sistema</p>
            </div>
          </div>

          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-900/30 text-red-400 hover:bg-red-900/50 transition-colors"
          >
            <ArrowRightOnRectangleIcon className="h-5 w-5" />
            Sair
          </button>
        </div>

        <div className="max-w-7xl mx-auto px-6 flex gap-2 overflow-x-auto pb-2">
          {[
            { id: "dashboard", label: "Dashboard", icon: ChartBarIcon },
            { id: "usuarios", label: "Usuários", icon: UserGroupIcon },
            { id: "saques", label: "Saques", icon: BanknotesIcon },
            { id: "planos", label: "Planos", icon: Cog6ToothIcon },
            { id: "config", label: "Configurações", icon: KeyIcon },
            // Add sponsorships tab to header navigation
            { id: "sponsorships", label: "Patrocínios", icon: UserGroupIcon }, // Using UserGroupIcon as a placeholder, ideally a specific icon
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold transition-all whitespace-nowrap ${
                activeTab === tab.id ? "bg-purple-600 text-white" : "bg-slate-700/50 text-slate-300 hover:bg-slate-700"
              }`}
            >
              <tab.icon className="h-5 w-5" />
              {tab.label}
            </button>
          ))}
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "dashboard" && (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold">Visão Geral do Sistema</h2>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="rounded-2xl bg-gradient-to-br from-green-600 to-emerald-600 p-6 shadow-xl">
                <p className="text-sm text-green-100 mb-2">💰 Total Depositado</p>
                <p className="text-4xl font-bold">R$ {totalDepositos.toFixed(2)}</p>
                <p className="text-sm text-green-200 mt-2">Entradas na plataforma</p>
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-red-600 to-pink-600 p-6 shadow-xl">
                <p className="text-sm text-red-100 mb-2">💸 Total Sacado</p>
                <p className="text-4xl font-bold">R$ {totalSaques.toFixed(2)}</p>
                <p className="text-sm text-red-200 mt-2">Saídas da plataforma</p>
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-600 p-6 shadow-xl">
                <p className="text-sm text-purple-100 mb-2">💎 Saldo Total Usuários</p>
                <p className="text-4xl font-bold">R$ {saldoTotal.toFixed(2)}</p>
                <p className="text-sm text-purple-200 mt-2">Disponível para saque</p>
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-amber-600 to-orange-600 p-6 shadow-xl">
                <p className="text-sm text-amber-100 mb-2">👥 Total Usuários</p>
                <p className="text-4xl font-bold">{usuarios.length}</p>
                <p className="text-sm text-amber-200 mt-2">Cadastrados na plataforma</p>
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-600 p-6 shadow-xl">
                <p className="text-sm text-blue-100 mb-2">📈 Rendimentos Gerados</p>
                <p className="text-4xl font-bold">R$ {rendimentoTotal.toFixed(2)}</p>
                <p className="text-sm text-blue-200 mt-2">Lucro dos investidores</p>
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-pink-600 to-rose-600 p-6 shadow-xl">
                <p className="text-sm text-pink-100 mb-2">🎯 Pacotes Ativos</p>
                <p className="text-4xl font-bold">{pacotesAtivos}</p>
                <p className="text-sm text-pink-200 mt-2">Investimentos ativos</p>
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-yellow-600 to-amber-600 p-6 shadow-xl">
                <p className="text-sm text-yellow-100 mb-2">⏳ Saques Pendentes</p>
                <p className="text-4xl font-bold">{saquesPendentes.length}</p>
                <p className="text-sm text-yellow-200 mt-2">Aguardando aprovação</p>
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-teal-600 to-emerald-600 p-6 shadow-xl">
                <p className="text-sm text-teal-100 mb-2">💹 Lucro Plataforma</p>
                <p className="text-4xl font-bold">R$ {(totalDepositos - totalSaques).toFixed(2)}</p>
                <p className="text-sm text-teal-200 mt-2">Saldo da empresa</p>
              </div>
            </div>

            <div className="rounded-2xl bg-slate-800/50 backdrop-blur-xl border border-slate-700 p-6">
              <h3 className="text-xl font-bold mb-4">📊 Transações Recentes</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-700">
                      <th className="text-left py-3 px-4 text-sm font-semibold">Tipo</th>
                      <th className="text-left py-3 px-4 text-sm font-semibold">Usuário</th>
                      <th className="text-left py-3 px-4 text-sm font-semibold">Valor</th>
                      <th className="text-left py-3 px-4 text-sm font-semibold">Status</th>
                      <th className="text-left py-3 px-4 text-sm font-semibold">Data</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transacoes.slice(0, 15).map((t) => {
                      const user = usuarios.find((u) => u.id === t.userId)
                      return (
                        <tr key={t.id} className="border-b border-slate-700/50 hover:bg-slate-700/30">
                          <td className="py-3 px-4">
                            <span
                              className={`px-2 py-1 rounded-lg text-xs font-bold ${
                                t.tipo === "DEPOSITO"
                                  ? "bg-green-900/30 text-green-400"
                                  : t.tipo === "SAQUE"
                                    ? "bg-red-900/30 text-red-400"
                                    : "bg-blue-900/30 text-blue-400"
                              }`}
                            >
                              {t.tipo}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-sm">{user?.nome || "Sistema"}</td>
                          <td className="py-3 px-4 font-bold text-lg">R$ {t.valor.toFixed(2)}</td>
                          <td className="py-3 px-4">
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-semibold ${
                                t.status === "APROVADO"
                                  ? "bg-green-900/30 text-green-400"
                                  : t.status === "PROCESSANDO"
                                    ? "bg-amber-900/30 text-amber-400"
                                    : "bg-red-900/30 text-red-400"
                              }`}
                            >
                              {t.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-sm">{new Date(t.data).toLocaleString("pt-BR")}</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "usuarios" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-bold">👥 Gerenciar Usuários</h2>
              <div className="px-4 py-2 rounded-xl bg-purple-900/30 text-purple-400 font-bold">
                {usuarios.length} Cadastrados
              </div>
            </div>

            {selectedUserForBalance && (
              <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-6">
                <div className="bg-slate-900 rounded-3xl p-8 max-w-md w-full border border-slate-700">
                  <h3 className="text-2xl font-bold mb-6">💰 Ajustar Saldo Manual</h3>
                  <p className="text-slate-400 mb-4">
                    Usuário: <strong>{selectedUserForBalance.nome}</strong>
                  </p>
                  <p className="text-slate-400 mb-6">
                    Saldo Atual:{" "}
                    <strong className="text-green-400">R$ {selectedUserForBalance.saldo.toFixed(2)}</strong>
                  </p>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-semibold mb-2">
                        Valor do Ajuste (+ para adicionar, - para remover)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={balanceAdjustment}
                        onChange={(e) => setBalanceAdjustment(e.target.value)}
                        placeholder="Ex: 100.00 ou -50.00"
                        className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2">Motivo do Ajuste</label>
                      <textarea
                        value={adjustmentReason}
                        onChange={(e) => setAdjustmentReason(e.target.value)}
                        placeholder="Ex: Bônus especial, correção de erro, etc."
                        rows={3}
                        className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                    </div>

                    <div className="flex gap-3">
                      <button
                        onClick={handleBalanceAdjustment}
                        className="flex-1 rounded-xl bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 py-3 text-white font-bold transition-all"
                      >
                        Confirmar Ajuste
                      </button>
                      <button
                        onClick={() => {
                          setSelectedUserForBalance(null)
                          setBalanceAdjustment("")
                          setAdjustmentReason("")
                        }}
                        className="flex-1 rounded-xl bg-slate-700 hover:bg-slate-600 py-3 text-white font-bold transition-all"
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-4">
              {usuarios.map((user: any) => (
                <div
                  key={user.id}
                  className="rounded-2xl bg-slate-800/50 backdrop-blur-xl border border-slate-700 p-6 hover:border-purple-500/50 transition-all"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="text-xl font-bold">{user.nome}</h4>
                      <p className="text-sm text-slate-400">{user.email}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-green-400">R$ {user.saldo.toFixed(2)}</p>
                      <p className="text-sm text-slate-500">ID: {user.id}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    <div>
                      <span className="text-slate-400">Telefone:</span>
                      <p className="font-semibold">{user.telefone}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Rendimento:</span>
                      <p className="font-semibold text-green-400">R$ {user.rendimento.toFixed(2)}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Indicados:</span>
                      <p className="font-semibold">{user.indicados}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Bônus Ref:</span>
                      <p className="font-semibold text-purple-400">R$ {user.bonusRef.toFixed(2)}</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => setSelectedUserForBalance(user)}
                      className="px-4 py-2 rounded-lg bg-green-600/20 text-green-400 border border-green-500/30 hover:bg-green-600/30 transition-all text-sm font-semibold"
                    >
                      💰 Ajustar Saldo
                    </button>
                    <button
                      onClick={() => deleteUser(user.id)}
                      className="px-4 py-2 rounded-lg bg-red-600/20 text-red-400 border border-red-500/30 hover:bg-red-600/30 transition-all text-sm font-semibold"
                    >
                      🗑️ Deletar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "saques" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-bold">💸 Gerenciar Saques</h2>
              <div className="px-4 py-2 rounded-xl bg-amber-900/30 text-amber-400 font-bold">
                {saquesPendentes.length} Pendentes
              </div>
            </div>

            <div className="space-y-4">
              {saquesPendentes.length === 0 ? (
                <div className="rounded-2xl bg-slate-800/50 backdrop-blur-xl border border-slate-700 p-12 text-center">
                  <CheckCircleIcon className="h-16 w-16 text-green-500 mx-auto mb-4" />
                  <p className="text-xl font-semibold text-slate-300">✅ Nenhum saque pendente!</p>
                  <p className="text-sm text-slate-400 mt-2">Todos os saques foram processados</p>
                </div>
              ) : (
                saquesPendentes.map((saque) => {
                  const user = usuarios.find((u) => u.id === saque.userId)
                  return (
                    <div
                      key={saque.id}
                      className="rounded-2xl bg-slate-800/50 backdrop-blur-xl border border-amber-500 p-6 shadow-xl"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-4">
                            <BanknotesIcon className="h-10 w-10 text-amber-400" />
                            <div>
                              <p className="text-3xl font-bold text-amber-400">R$ {saque.valor.toFixed(2)}</p>
                              <p className="text-sm text-slate-400">{saque.descricao}</p>
                            </div>
                          </div>

                          {user && (
                            <div className="grid md:grid-cols-2 gap-4 mb-4">
                              <div className="p-4 rounded-xl bg-slate-700/50">
                                <p className="text-xs text-slate-400 mb-1">👤 Usuário</p>
                                <p className="font-bold text-lg">{user.nome}</p>
                                <p className="text-sm text-slate-400">{user.email}</p>
                                <p className="text-sm text-slate-400 mt-2">Saldo atual: R$ {user.saldo.toFixed(2)}</p>
                              </div>
                              <div className="p-4 rounded-xl bg-slate-700/50">
                                <p className="text-xs text-slate-400 mb-1">📅 Data Solicitação</p>
                                <p className="font-semibold text-lg">{new Date(saque.data).toLocaleString("pt-BR")}</p>
                                <p className="text-sm text-slate-400 mt-2">ID: #{saque.id}</p>
                              </div>
                            </div>
                          )}

                          <div className="p-4 rounded-xl bg-purple-900/20 border border-purple-700">
                            <p className="text-xs text-purple-300 mb-1">🔑 Identificador da Transação</p>
                            <code className="text-sm font-mono text-purple-400 break-all">
                              {saque.identifier || "N/A"}
                            </code>
                          </div>
                        </div>

                        <div className="flex flex-col gap-3">
                          <button
                            onClick={() => approveSaque(saque.id)}
                            className="px-6 py-3 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold flex items-center gap-2 transition-all shadow-lg"
                            title="Aprovar Saque"
                          >
                            <CheckCircleIcon className="h-5 w-5" />
                            Aprovar
                          </button>
                          <button
                            onClick={() => rejectSaque(saque.id)}
                            className="px-6 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold flex items-center gap-2 transition-all shadow-lg"
                            title="Rejeitar Saque"
                          >
                            <XCircleIcon className="h-5 w-5" />
                            Rejeitar
                          </button>
                        </div>
                      </div>
                    </div>
                  )
                })
              )}
            </div>
          </div>
        )}

        {activeTab === "planos" && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-bold">📊 Gerenciar Planos</h2>
              <button
                onClick={() =>
                  setEditingPlan({
                    id: Date.now(),
                    nome: "",
                    rendimentoDiario: 0,
                    valorMinimo: 0,
                    valorMaximo: 0,
                    ativo: true,
                  })
                }
                className="px-4 py-2 rounded-xl bg-green-600 hover:bg-green-700 font-bold transition-colors"
              >
                + Novo Plano
              </button>
            </div>

            {editingPlan && (
              <div className="rounded-2xl bg-slate-800/50 backdrop-blur-xl border border-purple-500 p-6 shadow-xl">
                <h3 className="text-xl font-bold mb-4">
                  {config.planos.find((p) => p.id === editingPlan.id) ? "Editar Plano" : "Novo Plano"}
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2">Nome do Plano</label>
                    <input
                      type="text"
                      value={editingPlan.nome}
                      onChange={(e) => setEditingPlan({ ...editingPlan, nome: e.target.value })}
                      className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">Rendimento Diário (%)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={editingPlan.rendimentoDiario}
                      onChange={(e) => setEditingPlan({ ...editingPlan, rendimentoDiario: Number(e.target.value) })}
                      className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">Valor Mínimo (R$)</label>
                    <input
                      type="number"
                      value={editingPlan.valorMinimo}
                      onChange={(e) => setEditingPlan({ ...editingPlan, valorMinimo: Number(e.target.value) })}
                      className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">Valor Máximo (R$)</label>
                    <input
                      type="number"
                      value={editingPlan.valorMaximo}
                      onChange={(e) => setEditingPlan({ ...editingPlan, valorMaximo: Number(e.target.value) })}
                      className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                </div>
                <div className="flex gap-3 mt-4">
                  <button
                    onClick={savePlano}
                    className="px-6 py-3 rounded-xl bg-purple-600 hover:bg-purple-700 font-bold transition-colors"
                  >
                    Salvar Plano
                  </button>
                  <button
                    onClick={() => setEditingPlan(null)}
                    className="px-6 py-3 rounded-xl bg-slate-700 hover:bg-slate-600 font-bold transition-colors"
                  >
                    Cancelar
                  </button>
                </div>
              </div>
            )}

            <div className="grid md:grid-cols-2 gap-6">
              {config.planos.map((plano) => (
                <div
                  key={plano.id}
                  className={`rounded-2xl border p-6 ${
                    plano.ativo ? "bg-slate-800/50 border-slate-700" : "bg-slate-800/20 border-slate-800 opacity-50"
                  }`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-2xl font-bold">{plano.nome}</h3>
                      <p className="text-3xl font-bold text-green-400 mt-2">{plano.rendimentoDiario}% / dia</p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setEditingPlan(plano)}
                        className="p-2 rounded-lg bg-blue-900/30 text-blue-400 hover:bg-blue-900/50"
                        title="Editar"
                      >
                        <PencilIcon className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => deletePlano(plano.id)}
                        className="p-2 rounded-lg bg-red-900/30 text-red-400 hover:bg-red-900/50"
                        title="Deletar"
                      >
                        <TrashIcon className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  <div className="space-y-2 text-sm mb-4">
                    <p>
                      <strong>Mínimo:</strong> R$ {plano.valorMinimo.toLocaleString()}
                    </p>
                    <p>
                      <strong>Máximo:</strong> R$ {plano.valorMaximo.toLocaleString()}
                    </p>
                  </div>
                  <button
                    onClick={() => togglePlanoAtivo(plano.id)}
                    className={`w-full rounded-xl py-3 font-bold transition-all ${
                      plano.ativo
                        ? "bg-red-600 hover:bg-red-700 text-white"
                        : "bg-green-600 hover:bg-green-700 text-white"
                    }`}
                  >
                    {plano.ativo ? "Desativar" : "Ativar"}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "config" && (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold">⚙️ Configurações Globais</h2>

            {/* API Configuration */}
            <div className="rounded-2xl bg-slate-800/50 backdrop-blur-xl border border-slate-700 p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <KeyIcon className="h-6 w-6 text-purple-400" />
                API PoseidonPay
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold mb-2">Client ID</label>
                  <input
                    type="text"
                    value={config.api.clientId}
                    onChange={(e) => setConfig({ ...config, api: { ...config.api, clientId: e.target.value } })}
                    className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 font-mono focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Client Secret</label>
                  <input
                    type="password"
                    value={config.api.clientSecret}
                    onChange={(e) => setConfig({ ...config, api: { ...config.api, clientSecret: e.target.value } })}
                    className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 font-mono focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Webhook URL (opcional)</label>
                  <input
                    type="url"
                    value={config.api.webhookUrl}
                    onChange={(e) => setConfig({ ...config, api: { ...config.api, webhookUrl: e.target.value } })}
                    placeholder="https://seudominio.com/api/webhooks/pix"
                    className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>
            </div>

            {/* Commissions Configuration */}
            <div className="rounded-2xl bg-slate-800/50 backdrop-blur-xl border border-slate-700 p-6">
              <h3 className="text-xl font-bold mb-4">💰 Comissões Multi-Nível</h3>
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-semibold mb-2">Nível 1 (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={config.comissoes.nivel1}
                    onChange={(e) =>
                      setConfig({ ...config, comissoes: { ...config.comissoes, nivel1: Number(e.target.value) } })
                    }
                    className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Nível 2 (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={config.comissoes.nivel2}
                    onChange={(e) =>
                      setConfig({ ...config, comissoes: { ...config.comissoes, nivel2: Number(e.target.value) } })
                    }
                    className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Nível 3 (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={config.comissoes.nivel3}
                    onChange={(e) =>
                      setConfig({ ...config, comissoes: { ...config.comissoes, nivel3: Number(e.target.value) } })
                    }
                    className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>
            </div>

            {/* Fees Configuration */}
            <div className="rounded-2xl bg-slate-800/50 backdrop-blur-xl border border-slate-700 p-6">
              <h3 className="text-xl font-bold mb-4">💸 Taxas do Sistema</h3>
              <div>
                <label className="block text-sm font-semibold mb-2">Taxa de Saque (%)</label>
                <input
                  type="number"
                  step="0.1"
                  value={config.taxas.saque}
                  onChange={(e) => setConfig({ ...config, taxas: { ...config.taxas, saque: Number(e.target.value) } })}
                  className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <p className="text-sm text-slate-400 mt-2">
                  Taxa cobrada sobre cada saque. Valor atual: {config.taxas.saque}%
                </p>
              </div>
            </div>

            {/* Fixed admin configuration synchronization */}
            <button
              onClick={() => {
                saveGlobalConfig(config)
                window.dispatchEvent(new Event("storage"))
                window.dispatchEvent(new CustomEvent("globalConfigUpdated"))
                setTimeout(() => {
                  window.dispatchEvent(new Event("storage"))
                  window.dispatchEvent(new CustomEvent("globalConfigUpdated"))
                }, 100)
                alert("Configurações salvas e sincronizadas em todo o site!")
                loadData()
              }}
              className="w-full rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 py-4 text-white text-lg font-bold shadow-xl transition-all"
            >
              💾 Salvar Todas as Configurações
            </button>

            <div className="p-4 rounded-xl bg-amber-900/20 border border-amber-700">
              <p className="text-sm text-amber-300">
                ⚠️ <strong>Atenção:</strong> Todas as alterações feitas aqui serão aplicadas imediatamente em todo o
                site. Certifique-se de que os valores estão corretos antes de salvar.
              </p>
            </div>
          </div>
        )}

        {activeTab === "sponsorships" && (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold">🤝 Patrocínios e Parcerias</h2>

            <div className="rounded-2xl bg-slate-800/50 backdrop-blur-xl border border-slate-700 p-6">
              <h3 className="text-xl font-bold mb-4">Adicionar Novo Patrocínio</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold mb-2">Nome do Patrocinador *</label>
                  <input
                    type="text"
                    value={newSponsor.name}
                    onChange={(e) => setNewSponsor({ ...newSponsor, name: e.target.value })}
                    placeholder="Nome da empresa"
                    className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Valor do Patrocínio *</label>
                  <input
                    type="number"
                    value={newSponsor.value}
                    onChange={(e) => setNewSponsor({ ...newSponsor, value: e.target.value })}
                    placeholder="10000.00"
                    className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Logo URL (opcional)</label>
                  <input
                    type="url"
                    value={newSponsor.logo}
                    onChange={(e) => setNewSponsor({ ...newSponsor, logo: e.target.value })}
                    placeholder="https://..."
                    className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">Website URL (opcional)</label>
                  <input
                    type="url"
                    value={newSponsor.url}
                    onChange={(e) => setNewSponsor({ ...newSponsor, url: e.target.value })}
                    placeholder="https://..."
                    className="w-full rounded-xl border border-slate-600 bg-slate-700 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>
              <button
                onClick={handleAddSponsorship}
                className="mt-4 w-full rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 py-3 font-bold transition-all"
              >
                Adicionar Patrocínio
              </button>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-bold">Patrocínios Ativos ({sponsorships.length})</h3>
              {sponsorships.map((sponsor) => (
                <div
                  key={sponsor.id}
                  className="rounded-2xl bg-slate-800/50 backdrop-blur-xl border border-slate-700 p-6"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      {sponsor.logo && (
                        <img
                          src={sponsor.logo || "/placeholder.svg"}
                          alt={sponsor.name}
                          className="h-12 w-12 rounded-lg object-cover"
                        />
                      )}
                      <div>
                        <h4 className="text-lg font-bold">{sponsor.name}</h4>
                        {sponsor.url && (
                          <a
                            href={sponsor.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-sm text-purple-400 hover:underline"
                          >
                            {sponsor.url}
                          </a>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-2xl font-bold text-green-400">R$ {Number(sponsor.value).toFixed(2)}</p>
                        <p className="text-sm text-slate-500">{new Date(sponsor.createdAt).toLocaleDateString()}</p>
                      </div>
                      <button
                        onClick={() => handleDeleteSponsorship(sponsor.id)}
                        className="px-4 py-2 rounded-lg bg-red-600/20 text-red-400 border border-red-500/30 hover:bg-red-600/30 transition-all"
                      >
                        Remover
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </main>
  )
}
