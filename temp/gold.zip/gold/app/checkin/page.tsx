"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  CalendarIcon,
  CheckCircleIcon,
  SparklesIcon,
  ArrowLeftIcon,
  GiftIcon,
  FireIcon,
} from "@heroicons/react/24/solid"

type CheckinDay = {
  day: number
  reward: number
  claimed: boolean
  date?: string
}

type User = {
  id: number
  nome: string
  email: string
  telefone: string
  senha: string
  sponsor: string
  saldo: number
  rendimento: number
  bonusRef: number
  indicados: number
  nivel: number
  dataCriacao: string
}

export default function CheckinPage() {
  const router = useRouter()
  const [checkins, setCheckins] = useState<CheckinDay[]>([])
  const [currentStreak, setCurrentStreak] = useState(0)
  const [totalEarned, setTotalEarned] = useState(0)
  const [canCheckIn, setCanCheckIn] = useState(true)
  const [lastCheckIn, setLastCheckIn] = useState<string | null>(null)

  useEffect(() => {
    // Initialize checkin data
    const savedCheckins = localStorage.getItem("checkins")
    const savedLastCheckIn = localStorage.getItem("lastCheckIn")

    if (savedCheckins) {
      const parsed = JSON.parse(savedCheckins)
      setCheckins(parsed)
      setCurrentStreak(parsed.filter((c: CheckinDay) => c.claimed).length)
      setTotalEarned(parsed.reduce((acc: number, c: CheckinDay) => (c.claimed ? acc + c.reward : acc), 0))
    } else {
      // Initialize 30 days
      const initialCheckins = Array.from({ length: 30 }, (_, i) => ({
        day: i + 1,
        reward: 1.0,
        claimed: false,
      }))
      setCheckins(initialCheckins)
    }

    if (savedLastCheckIn) {
      setLastCheckIn(savedLastCheckIn)
      const lastDate = new Date(savedLastCheckIn)
      const today = new Date()
      const diffTime = today.getTime() - lastDate.getTime()
      const diffDays = diffTime / (1000 * 3600 * 24)

      if (diffDays < 1) {
        setCanCheckIn(false)
      }
    }
  }, [])

  const handleCheckIn = () => {
    if (!canCheckIn) return

    const today = new Date().toISOString()
    const nextUnclaimed = checkins.findIndex((c) => !c.claimed)

    if (nextUnclaimed === -1) return

    const updatedCheckins = [...checkins]
    updatedCheckins[nextUnclaimed] = {
      ...updatedCheckins[nextUnclaimed],
      claimed: true,
      date: today,
    }

    const usuarioLogado = localStorage.getItem("usuarioLogado")
    if (usuarioLogado) {
      const usuario: User = JSON.parse(usuarioLogado)
      const rewardAmount = updatedCheckins[nextUnclaimed].reward

      const usuarioAtualizado = {
        ...usuario,
        saldo: usuario.saldo + rewardAmount,
      }

      localStorage.setItem("usuarioLogado", JSON.stringify(usuarioAtualizado))

      const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]")
      const index = usuarios.findIndex((u: User) => u.id === usuario.id)
      if (index !== -1) {
        usuarios[index] = usuarioAtualizado
        localStorage.setItem("usuarios", JSON.stringify(usuarios))
      }
    }

    setCheckins(updatedCheckins)
    setCurrentStreak(currentStreak + 1)
    setTotalEarned(totalEarned + updatedCheckins[nextUnclaimed].reward)
    setLastCheckIn(today)
    setCanCheckIn(false)

    localStorage.setItem("checkins", JSON.stringify(updatedCheckins))
    localStorage.setItem("lastCheckIn", today)
  }

  const getTimeUntilNextCheckIn = () => {
    if (!lastCheckIn) return "Disponível agora!"

    const lastDate = new Date(lastCheckIn)
    const nextCheckIn = new Date(lastDate.getTime() + 24 * 60 * 60 * 1000)
    const now = new Date()
    const diff = nextCheckIn.getTime() - now.getTime()

    if (diff <= 0) return "Disponível agora!"

    const hours = Math.floor(diff / (1000 * 60 * 60))
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

    return `${hours}h ${minutes}m`
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50 dark:from-slate-950 dark:via-indigo-950 dark:to-slate-900 text-slate-900 dark:text-slate-50 transition-all duration-500">
      {/* Header */}
      <header className="border-b border-slate-200/50 dark:border-slate-800/50 backdrop-blur-xl bg-white/50 dark:bg-slate-900/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.back()}
              className="p-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
            >
              <ArrowLeftIcon className="h-5 w-5" />
            </button>
            <div className="h-11 w-11 grid place-items-center rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 shadow-lg shadow-indigo-500/50">
              <SparklesIcon className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent">
              Check-in Diário
            </span>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-6 py-8 space-y-8">
        {/* Hero Section */}
        <div className="rounded-3xl bg-gradient-to-br from-green-600 via-emerald-600 to-teal-600 p-8 text-white shadow-2xl shadow-green-500/30">
          <div className="flex items-center gap-3 mb-4">
            <GiftIcon className="h-10 w-10" />
            <h1 className="text-4xl font-bold">Ganhe R$ 1,00 Todo Dia!</h1>
          </div>
          <p className="text-lg text-white/90 mb-6 max-w-2xl">
            Faça seu check-in diário e acumule R$ 30,00 por mês. Simples, rápido e totalmente grátis! O valor é
            creditado automaticamente no seu saldo.
          </p>

          <button
            onClick={handleCheckIn}
            disabled={!canCheckIn}
            className={`rounded-2xl px-8 py-4 text-xl font-bold shadow-2xl transition-all flex items-center gap-3 ${
              canCheckIn ? "bg-white text-green-600 hover:scale-105" : "bg-white/20 text-white/50 cursor-not-allowed"
            }`}
          >
            <CheckCircleIcon className="h-7 w-7" />
            {canCheckIn ? "Fazer Check-in Agora" : `Próximo em ${getTimeUntilNextCheckIn()}`}
          </button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6">
          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <FireIcon className="h-5 w-5 text-orange-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Sequência Atual</span>
            </div>
            <p className="text-4xl font-bold text-orange-600 dark:text-orange-400">{currentStreak} dias</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Mantenha a sequência!</p>
          </div>

          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <CalendarIcon className="h-5 w-5 text-green-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Total Acumulado</span>
            </div>
            <p className="text-4xl font-bold text-green-600 dark:text-green-400">R$ {totalEarned.toFixed(2)}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Creditado na conta</p>
          </div>

          <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <GiftIcon className="h-5 w-5 text-purple-500" />
              <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Próximo Bônus</span>
            </div>
            <p className="text-4xl font-bold text-purple-600 dark:text-purple-400">R$ 1,00</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              {canCheckIn ? "Disponível agora" : getTimeUntilNextCheckIn()}
            </p>
          </div>
        </div>

        {/* Calendar */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl p-6">
          <h3 className="text-xl font-bold mb-6">Calendário de Check-ins</h3>

          <div className="grid grid-cols-5 md:grid-cols-10 gap-3">
            {checkins.map((checkin) => (
              <div
                key={checkin.day}
                className={`aspect-square rounded-xl p-2 flex flex-col items-center justify-center transition-all ${
                  checkin.claimed
                    ? "bg-gradient-to-br from-green-500 to-emerald-600 text-white shadow-lg scale-105"
                    : "bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-600"
                }`}
              >
                <span className="text-xs font-semibold mb-1">Dia {checkin.day}</span>
                {checkin.claimed ? (
                  <CheckCircleIcon className="h-6 w-6" />
                ) : (
                  <span className="text-xs font-bold">R$ 1,00</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Tips */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 backdrop-blur-xl p-6">
          <h3 className="text-lg font-bold mb-4 text-blue-900 dark:text-blue-300">💡 Dicas para Maximizar Ganhos</h3>
          <ul className="space-y-2 text-sm text-blue-800 dark:text-blue-400">
            <li className="flex items-start gap-2">
              <span className="font-bold">•</span>
              <span>Configure um lembrete diário para não perder nenhum check-in</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-bold">•</span>
              <span>Faça check-in sempre no mesmo horário para criar o hábito</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-bold">•</span>
              <span>Combine com o programa de afiliados para ganhar ainda mais!</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-bold">•</span>
              <span>Os valores são creditados automaticamente na sua carteira</span>
            </li>
          </ul>
        </div>
      </div>
    </main>
  )
}
