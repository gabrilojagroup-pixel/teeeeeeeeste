export type User = {
  id: number
  email: string
  nome: string
  cpf?: string
  telefone?: string
  saldo: number
  rendimento: number
  bonusRef: number
  sponsor?: string
  referralCode?: string
  indicados?: number
  dataCriacao: string
}

export const generateReferralCode = (): string => {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
  let code = "FUT"
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return code
}

export const getUserByReferralCode = (code: string): User | null => {
  const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]") as User[]
  return usuarios.find((u) => u.referralCode === code) || null
}

export const processAffiliateBonus = (
  depositAmount: number,
  depositorEmail: string,
): {
  nivel1?: { email: string; amount: number }
  nivel2?: { email: string; amount: number }
  nivel3?: { email: string; amount: number }
} => {
  const config = getGlobalConfig()
  const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]") as User[]
  const bonuses: ReturnType<typeof processAffiliateBonus> = {}

  const depositor = usuarios.find((u) => u.email === depositorEmail)
  if (!depositor || !depositor.sponsor) return bonuses

  const level1User = usuarios.find((u) => u.referralCode === depositor.sponsor)
  if (level1User) {
    const level1Amount = (depositAmount * config.comissoes.nivel1) / 100
    level1User.saldo += level1Amount
    level1User.bonusRef = (level1User.bonusRef || 0) + level1Amount
    level1User.indicados = (level1User.indicados || 0) + 1
    bonuses.nivel1 = { email: level1User.email, amount: level1Amount }

    if (level1User.sponsor) {
      const level2User = usuarios.find((u) => u.referralCode === level1User.sponsor)
      if (level2User) {
        const level2Amount = (depositAmount * config.comissoes.nivel2) / 100
        level2User.saldo += level2Amount
        level2User.bonusRef = (level2User.bonusRef || 0) + level2Amount
        bonuses.nivel2 = { email: level2User.email, amount: level2Amount }

        if (level2User.sponsor) {
          const level3User = usuarios.find((u) => u.referralCode === level2User.sponsor)
          if (level3User) {
            const level3Amount = (depositAmount * config.comissoes.nivel3) / 100
            level3User.saldo += level3Amount
            level3User.bonusRef = (level3User.bonusRef || 0) + level3Amount
            bonuses.nivel3 = { email: level3User.email, amount: level3Amount }
          }
        }
      }
    }
  }

  localStorage.setItem("usuarios", JSON.stringify(usuarios))

  const loggedUser = localStorage.getItem("usuarioLogado")
  if (loggedUser) {
    const user = JSON.parse(loggedUser)
    const updated = usuarios.find((u) => u.email === user.email)
    if (updated && (updated.bonusRef !== user.bonusRef || updated.saldo !== user.saldo)) {
      localStorage.setItem("usuarioLogado", JSON.stringify(updated))
      window.dispatchEvent(new Event("userUpdated"))
    }
  }

  return bonuses
}

export const countIndicados = (userEmail: string, level: 1 | 2 | 3 = 1): number => {
  const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]") as User[]
  const user = usuarios.find((u) => u.email === userEmail)
  if (!user || !user.referralCode) return 0

  if (level === 1) {
    return usuarios.filter((u) => u.sponsor === user.referralCode).length
  } else if (level === 2) {
    const level1 = usuarios.filter((u) => u.sponsor === user.referralCode)
    let count = 0
    level1.forEach((l1) => {
      if (l1.referralCode) {
        count += usuarios.filter((u) => u.sponsor === l1.referralCode).length
      }
    })
    return count
  } else {
    const level1 = usuarios.filter((u) => u.sponsor === user.referralCode)
    let count = 0
    level1.forEach((l1) => {
      if (l1.referralCode) {
        const level2 = usuarios.filter((u) => u.sponsor === l1.referralCode)
        level2.forEach((l2) => {
          if (l2.referralCode) {
            count += usuarios.filter((u) => u.sponsor === l2.referralCode).length
          }
        })
      }
    })
    return count
  }
}

import { getGlobalConfig } from "./global-config"
