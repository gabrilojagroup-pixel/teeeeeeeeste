const PUBLIC_KEY = "naves-exee_3k7tulny3z5n2ls6"
const SECRET_KEY = "xxhlx5oiaxreraksid4htz1jg683ts14w9g2o4ukarqpu164mtpzpb31byvs3fn1"
const API_BASE_URL = "https://app.poseidonpay.site/api/v1"

export interface PixPaymentResponse {
  transactionId: string
  status: "OK" | "FAILED" | "PENDING" | "REJECTED" | "CANCELED"
  fee: number
  order: {
    id: string
    url?: string
  }
  pix: {
    code: string
    base64?: string
    image?: string
  }
  details?: string
  errorDescription?: string
}

export interface TransactionResponse {
  id: string
  clientIdentifier: string
  currency: string
  amount: number
  chargeAmount: number
  exchangeRate: number
  producerExtraAmount: number
  status: "PENDING" | "COMPLETED" | "FAILED" | "REFUNDED" | "CHARGED_BACK"
  statusDescription?: string
  purchaseType: "ONCE" | "RECURRING"
  paymentMethod: "PIX" | "CREDIT_CARD" | "BOLETO" | "TED" | "SPLIT" | "DYNAMIC" | "CRYPTO"
  details?: string
  errorDescription?: string
  webhookUrl?: string
  createdAt: string
  availableAt: string
  payedAt?: string
  refundedAt?: string
  pixInformation?: {
    qrCode: string
    image?: string
    base64?: string
  }
  pixMetadata?: {
    payerDocument?: string
    payerName?: string
    payerBankName?: string
    payerBankAccount?: string
    payerBankBranch?: string
    receiverDocument?: string
    receiverName?: string
    receiverPixKey?: string
    receiverBankName?: string
    receiverBankAccount?: string
    receiverBankBranch?: string
  }
}

export interface BalanceResponse {
  available: number
  pending: number
  fundLock: number
}

export class PoseidonAPI {
  private headers = {
    "Content-Type": "application/json",
    "x-public-key": PUBLIC_KEY,
    "x-secret-key": SECRET_KEY,
  }

  async createPixPayment(data: {
    identifier: string
    amount: number
    client: {
      name: string
      email: string
      phone: string
      document: string
    }
    callbackUrl?: string
  }): Promise<PixPaymentResponse> {
    const response = await fetch(`${API_BASE_URL}/gateway/pix/receive`, {
      method: "POST",
      headers: this.headers,
      body: JSON.stringify(data),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Erro ao criar pagamento PIX")
    }

    return response.json()
  }

  async getTransaction(params: { id?: string; clientIdentifier?: string }): Promise<TransactionResponse> {
    const queryParams = new URLSearchParams()
    if (params.id) queryParams.append("id", params.id)
    if (params.clientIdentifier) queryParams.append("clientIdentifier", params.clientIdentifier)

    const response = await fetch(`${API_BASE_URL}/gateway/transactions?${queryParams.toString()}`, {
      headers: this.headers,
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Erro ao buscar transação")
    }

    return response.json()
  }

  async getBalance(): Promise<BalanceResponse> {
    const response = await fetch(`${API_BASE_URL}/gateway/producer/balance`, {
      headers: this.headers,
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Erro ao buscar saldo")
    }

    return response.json()
  }

  async testCredentials() {
    const response = await fetch(`${API_BASE_URL}/gateway/producer/credentials`, {
      headers: this.headers,
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Credenciais inválidas")
    }

    return response.json()
  }

  async createWithdrawal(data: {
    identifier: string
    amount: number
    pixKey: string
    pixKeyType: "CPF" | "CNPJ" | "EMAIL" | "PHONE" | "RANDOM"
    receiverName: string
    receiverDocument: string
    clientIp?: string
  }): Promise<any> {
    const pixTypeMap: Record<string, string> = {
      CPF: "cpf",
      CNPJ: "cnpj",
      EMAIL: "email",
      PHONE: "phone",
      RANDOM: "random",
    }

    const cleanDocument = data.receiverDocument.replace(/\D/g, "")
    const documentType = cleanDocument.length === 11 ? "cpf" : "cnpj"

    const response = await fetch(`${API_BASE_URL}/gateway/transfers`, {
      method: "POST",
      headers: this.headers,
      body: JSON.stringify({
        identifier: data.identifier,
        amount: data.amount,
        pix: {
          type: pixTypeMap[data.pixKeyType] || data.pixKeyType.toLowerCase(),
          key: data.pixKey,
        },
        owner: {
          name: data.receiverName,
          document: {
            type: documentType,
            number: cleanDocument,
          },
          ip: data.clientIp || "127.0.0.1",
        },
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      let errorMessage = "Erro ao criar saque"
      try {
        const errorJson = JSON.parse(errorText)
        errorMessage = errorJson.message || errorMessage
      } catch {
        errorMessage = errorText
      }
      throw new Error(errorMessage)
    }

    return response.json()
  }

  async getTransferStatus(params: { id?: string; clientIdentifier?: string }): Promise<any> {
    const queryParams = new URLSearchParams()
    if (params.id) queryParams.append("id", params.id)
    if (params.clientIdentifier) queryParams.append("clientIdentifier", params.clientIdentifier)

    const response = await fetch(`${API_BASE_URL}/gateway/transfers?${queryParams.toString()}`, {
      headers: this.headers,
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Erro ao buscar status do saque")
    }

    return response.json()
  }
}

export const poseidonAPI = new PoseidonAPI()
