export type GlobalConfig = {
  api: {
    clientId: string
    clientSecret: string
    webhookUrl: string
  }
  comissoes: {
    nivel1: number
    nivel2: number
    nivel3: number
  }
  taxas: {
    saque: number
  }
  limites: {
    depositoMinimo: number
    saqueMinimo: number
  }
  planos: {
    id: number
    nome: string
    rendimentoDiario: number
    valorMinimo: number
    valorMaximo: number
    ativo: boolean
  }[]
}

export const getGlobalConfig = (): GlobalConfig => {
  if (typeof window === "undefined") {
    return getDefaultConfig()
  }

  const saved = localStorage.getItem("globalConfig")
  return saved ? JSON.parse(saved) : getDefaultConfig()
}

export const saveGlobalConfig = (config: GlobalConfig): void => {
  if (typeof window !== "undefined") {
    localStorage.setItem("globalConfig", JSON.stringify(config))
    window.dispatchEvent(new Event("storage"))
    window.dispatchEvent(new StorageEvent("storage", { key: "globalConfig" }))
    window.dispatchEvent(new Event("globalConfigUpdated"))
    // Force re-render of all components using the config
    setTimeout(() => {
      window.dispatchEvent(new Event("storage"))
    }, 100)
  }
}

export const getDefaultConfig = (): GlobalConfig => ({
  api: {
    clientId: "naves-exee_3k7tulny3z5n2ls6",
    clientSecret: "xxhlx5oiaxreraksid4htz1jg683ts14w9g2o4ukarqpu164mtpzpb31byvs3fn1",
    webhookUrl: "",
  },
  comissoes: {
    nivel1: 15,
    nivel2: 3,
    nivel3: 2,
  },
  taxas: {
    saque: 15,
  },
  limites: {
    depositoMinimo: 30,
    saqueMinimo: 30,
  },
  planos: [
    { id: 1, nome: "Starter", rendimentoDiario: 1.5, valorMinimo: 30, valorMaximo: 999, ativo: true },
    { id: 2, nome: "Professional", rendimentoDiario: 24, valorMinimo: 1000, valorMaximo: 4999, ativo: true },
    { id: 3, nome: "Elite", rendimentoDiario: 28, valorMinimo: 5000, valorMaximo: 19999, ativo: true },
    { id: 4, nome: "Diamond", rendimentoDiario: 32, valorMinimo: 20000, valorMaximo: 999999, ativo: true },
  ],
})
